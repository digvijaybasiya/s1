<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class uploadVideoTags extends Model
{
    use HasFactory;
    protected $table = 'upload_video_tag';

    protected $fillable = [
        'media_taggs_id','upload_video_id','media_taggs_user_id'
    ];
}
