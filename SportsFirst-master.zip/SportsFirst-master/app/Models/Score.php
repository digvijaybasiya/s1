<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Score extends Model
{
    use HasFactory;
    protected $table = 'score';
    protected $fillable = [
        'score_date', 'match_no', 'run','economy','percentage','best_avg','user_id','coach_id'
    ];
}
