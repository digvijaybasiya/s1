<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class uploadVideo extends Model
{
    use HasFactory;
    protected $table = 'upload_video';

    protected $fillable = [
        'title','video_url', 'user_id','taggs'
    ];
}
