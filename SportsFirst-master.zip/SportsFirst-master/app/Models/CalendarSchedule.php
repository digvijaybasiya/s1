<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CalendarSchedule extends Model
{
    use HasFactory;
    protected $fillable = [
        'event_name', 
        'event_location', 
        'event_start', 
        'event_end',
        'athlete_id',
        'coach_id'
    ];  
}
