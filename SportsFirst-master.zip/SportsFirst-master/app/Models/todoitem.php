<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class todoitem extends Model
{
    use HasFactory;
    protected $table = 'todoitem';

    protected $fillable = [
        'to_do_task', 'to_do_due_date', 'user_id'
    ];
}
