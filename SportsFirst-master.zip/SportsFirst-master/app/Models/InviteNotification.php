<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InviteNotification extends Model
{
    use HasFactory;
    protected $fillable = [
        'invite_coach_id',
        'invite_email',
        'invite_message'
    ];  
}
