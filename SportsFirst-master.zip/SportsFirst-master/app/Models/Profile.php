<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Profile extends Model
{
    use HasFactory;
    protected $table = 'profiles';

    protected $fillable = [
        'last_name', 'DOB', 'gender','blood_group','city','weight','pincode','state','address','sports_name','position','training_days','user_id'
    ];
}
