<?php

namespace App\Http\Controllers;
namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Support\Facades\Validator;
use DB;

class CustomLoginController extends Controller
{
    public function index()
    {
        return view('Auth.login');
    } 
    public function customLogin(Request $request)
    {
        $userData = DB::table('users')->where('email', $request->email)->first();
        if($userData){
            if(count(array($userData))){
                if($userData->is_email_verified == 1){
                    $request->validate([
                        'email' => 'required',
                        'password' => 'required',
                    ]);
               
                    $credentials = $request->only('email', 'password');
                    if (Auth::attempt($credentials)) {
                        return $response = [
                            'success'=>1,
                            'message'=>'Successfully loggedIn'
                        ];
                    }else{
                        return $response = [
                            'success'=>0,
                            'message'=>'Please enter valid Credentials.'
                        ];
                    }
                }else{
                    return $response = [
                        'success'=>0,
                        'message'=>'Please verify email first',
                    ];
                    // return view('Auth.verified_email',['response'=>$response]);
                }
            }
        }else{
            return $response = [
                'success'=>0,
                'message'=>'Please verify email',
            ];
        }
    }
}
