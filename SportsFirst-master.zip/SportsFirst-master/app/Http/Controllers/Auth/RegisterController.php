<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use DB;
use Session;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest');
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'phone_number' => ['required', 'integer', 'digits:10'],
            'password' => ['required', 'string', 'min:8','regex:/^.*(?=.{3,})(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[\d\x])(?=.*[!$#%@]).*/'],
            'user_type' => ['required', 'integer'],
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return \App\Models\User
     */
    protected function create(array $data)
    {
        $appUrl = env('APP_URL');

        $user_can_register=true;
        $coach_id=null;
        $selected_athlete_id=null;

        if($data['user_type']=='1' || $data['user_type']=='3'){
            if(session('invite_coach_id')){
                $user_can_register=true;               

                $invite_data=DB::table('invite_notification')->where('invite_email','=',$data['email'])->first();

                $coach_id= $invite_data->invite_coach_id; //session('invite_coach_id');
                $selected_athlete_id = $data['selected_athlete_id'];
            }else{
                $user_can_register=false;
            }
        }else if($data['user_type']=='2'){
            $user_can_register=true;
        }else if($data['user_type']=='3'){
            $user_can_register=true;
        }else{
            $user_can_register=false;
        }

        if($user_can_register==true){
            $create_user = User::create([
                'name' => $data['name'],
                'email' => $data['email'],
                'phone_number' => $data['phone_number'],
                'password' => Hash::make($data['password']),
                'user_type' => $data['user_type'],
                'coach_id'=>$coach_id,
                'athlete_id'=>$selected_athlete_id
            ]);
            if($create_user){
                if($data['user_type']=='1'){
                    DB::table('invite_notification')->where([['invite_email',$data['email']],['invite_coach_id',$coach_id]])->delete();
                }
                $hashId = str_replace('/', ' ', Hash::make($data['email']));
                $YOUR_API_KEY="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";

                $subject = "Verify its you";
                $to = $data['email'];
                $body = "<html><head></head><body><div><h1>Verify Email</h1></div><p>Hello $create_user->name,</p>Please verify your email by clicking <b><a href='$appUrl/verify/$hashId/$create_user->id'>Verify Email</a></b> link.</p></body></html>";
                // $body = "<html><head></head><body><div><h1>Verify Email</h1></div><p>Hello $create_user->name,</p>Please verify your email by clicking <b><a href='http://127.0.0.1:8000/verify/$hashId/$create_user->id'>Verify Email</a></b> link.</p></body></html>";


                $ch = curl_init();

                curl_setopt($ch, CURLOPT_URL, 'https://api.sendinblue.com/v3/smtp/email');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                // curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"$data['name']\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");
                curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"John Doe\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");

                $headers = array();
                $headers[] = 'Accept: application/json';
                $headers[] = "Api-Key: $YOUR_API_KEY";
                $headers[] = 'Content-Type: application/json';
                curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

                $result = curl_exec($ch);
                if (curl_errno($ch)) {
                echo 'Error:' . curl_error($ch);
                }
                curl_close($ch);

                $result = json_decode($result, TRUE);  

                //echo "<pre>"; print_r($result); exit;
                if(!empty($result['messageId'])){
                    echo "Email Sent and ID :".$result['messageId'];
                    session()->forget('invite_coach_id');
                    session()->forget('invite_mail');
                }
                else{
                    echo "Email Not Sent ";
                }
                return redirect()->route('register_success');
                // return redirect('register_success');
            }
        }else{
            Session::flash('error_msg', 'Registartion can not be done now');
        }
    }
    protected function create_old(array $data)
    {
        $appUrl = env('APP_URL');
        $create_user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'phone_number' => $data['phone_number'],
            'password' => Hash::make($data['password']),
            'user_type' => $data['user_type'],
        ]);
        if($create_user){
            $hashId = str_replace('/', ' ', Hash::make($data['email']));
            $YOUR_API_KEY="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";

            $subject = "Verify its you";
            $to = $data['email'];
            $body = "<html><head></head><body><div><h1>Verify Email</h1></div><p>Hello $create_user->name,</p>Please verify your email by clicking <b><a href='$appUrl/verify/$hashId/$create_user->id'>Verify Email</a></b> link.</p></body></html>";
            // $body = "<html><head></head><body><div><h1>Verify Email</h1></div><p>Hello $create_user->name,</p>Please verify your email by clicking <b><a href='http://127.0.0.1:8000/verify/$hashId/$create_user->id'>Verify Email</a></b> link.</p></body></html>";


            $ch = curl_init();

            curl_setopt($ch, CURLOPT_URL, 'https://api.sendinblue.com/v3/smtp/email');
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_POST, 1);
            // curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"$data['name']\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");
            curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"John Doe\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");

            $headers = array();
            $headers[] = 'Accept: application/json';
            $headers[] = "Api-Key: $YOUR_API_KEY";
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

            $result = curl_exec($ch);
            if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
            }
            curl_close($ch);

            $result = json_decode($result, TRUE);  

            //echo "<pre>"; print_r($result); exit;
            if(!empty($result['messageId'])){
                echo "Email Sent and ID :".$result['messageId'];
            }
            else{
                echo "Email Not Sent ";
            }
            return redirect()->route('register_success');
            // return redirect('register_success');
        }
        // return User::create([
        //     'name' => $data['name'],
        //     'email' => $data['email'],
        //     'phone_number' => $data['phone_number'],
        //     'password' => Hash::make($data['password']),
        //     'user_type' => $data['user_type'],
        // ]);
    }
    protected function verify_email($hashId,$id){
        $original_hash = str_replace(' ', '/', $hashId);
        if($id){
            $userData = (DB::table('users')->where('id', $id)->first());
            if(Hash::check($userData->email,$original_hash)){
                if($userData->is_email_verified == 1){
                    $response = [
                        'success'=>0,
                        'message'=>'Alreday verified'
                    ];
                }else{
                    $userUpdateData = DB::table('users')->where('id', $id)->update(["is_email_verified"=>1]);
                    if($userUpdateData){
                        $response = [
                            'success'=>1,
                            'message'=>'Successfully verified'
                        ];
                    }
                }
            }else{
                $response = [
                    'success'=>0,
                    'message'=>'Please provide valid link',
                ];
            }
            return view('Auth.verified_email',['response'=>$response]);
        }
    }
}
