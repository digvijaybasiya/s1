<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
// use App\Http\Requests\JsonRequest;
use App\Models\uploadVideo;
use App\Models\uploadVideoTags;
use DB;
use Illuminate\Support\Facades\Auth;

class UploadVideoController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        if(Auth::user()->user_type == 3)
            $user_id = Auth::user()->athlete_id;
        elseif(Auth::user()->user_type == 1 || Auth::user()->user_type == 2)
            $user_id = Auth::user()->id;
        $mediaTags = DB::table('media_taggs')->get();
        $videoData = DB::table('upload_video')->where('user_id',$user_id)->get();
        return view('Video.add',['videoData'=>$videoData,'tags'=>$mediaTags]);
    }
    public function upload(Request $request)
    {
        
        $data = $_POST; //echo json_encode($data);exit;
        $selectedTags = json_encode($data['medianTaggs']); 
        $request->validate([
            'file' => 'required',
        ]);
        $fileName = time().'.'.$request->file->extension();
        $filePath = 'uploads';
        $path = Storage::disk('s3')->put($filePath, $request->file);
        $path = Storage::disk('s3')->url($path);
        // echo json_encode($path);
        if($path){
            $videoData = [
                "title"=>$data['videoTitle'],
                "video_url"=>$path,
                "taggs"=>$selectedTags,
                "user_id"=>auth()->user()->id
            ];
            $addVideo = new uploadVideo($videoData);
            if($addVideo->save()){
                $selectedMediaTags = $data['medianTaggs'];
                foreach($selectedMediaTags as $selectedMediaTags){
                    $mediaTagsUpload = [
                        'media_taggs_id'=>$selectedMediaTags,
                        'upload_video_id'=>$addVideo->id,
                        'media_taggs_user_id'=>auth()->user()->id
                    ];
                    $addVideoTags = new uploadVideoTags($mediaTagsUpload);
                    $addVideoTags->save();
                }
                $response = [
                    'status'=>1,
                    'message'=>'Video added successfully'
                ];
            }else{
                $response = [
                    'status'=>0,
                    'message'=>'Video cannot be added'
                ];
            }
        }else{
            $response = [
                'status'=>0,
                'message'=>'For some reasons not able to upload video'
            ];
        }
         return $response;
    }
    public function upload_old(Request $request)
    {
        
        $data = $_POST;
        $user_id = Auth::user()->id;    
        $request->validate([
            'file' => 'required',
        ]);
        $fileName = time().'.'.$request->file->extension();
        $filePath = 'uploads';
        $path = Storage::disk('s3')->put($filePath, $request->file);
        $path = Storage::disk('s3')->url($path);
        // echo json_encode($path);
        if($path){
            $videoData = [
                "video_url"=>$path,
                "user_id"=>$user_id
            ];
            $addVideo = new uploadVideo($videoData);
            if($addVideo->save()){
                $response = [
                    'success'=>1,
                    'message'=>'Video added successfully'
                ];
            }else{
                $response = [
                    'success'=>0,
                    'message'=>'Video cannot be added'
                ];
            }
        }else{
            $response = [
                'success'=>0,
                'message'=>'For some reasons not able to upload video'
            ];
        }
        return $response;
    }
    public function displayVideo()
    {
        $user_id = Auth::user()->coach_id;
        $videoData = $this->getAthletePracticeVideo($user_id);
        $mediaTags = DB::table('media_taggs')->get();
        return view('Video.displayVideo',['videoData'=>$videoData,'mediaTags'=>$mediaTags,'coach_id'=>$user_id]);
    }
    public function getAthletePracticeVideo($user_id){
        $videoData = DB::table('upload_video')->where('user_id',$user_id)->get();
        return $videoData;
    }
    public function openVideo($athlete_id,$videoId){
        $videoData = DB::table('upload_video')->where('user_id',$athlete_id)->where('id',$videoId)->get();
        return $videoData;
    }
    public function athlete_openVideo(Request $request){
        if(Auth::user()->user_type == 3)
            $athlete_id = Auth::user()->athlete_id;
        elseif(Auth::user()->user_type == 1 || Auth::user()->user_type == 2)
            $athlete_id = Auth::user()->id;
        $videoId = $request->videoid;;
            // $athlete_id = Auth::user()->id;
            $videoData = $this->openVideo($athlete_id,$videoId);
        return view('Video.openVideoAthlete',['videoData'=>$videoData]);
    }
    public function coach_openVideo(Request $request){
        $videoId = $request->videoid;
            $athlete_id = $request->id;
            $videoData = $this->openVideo($athlete_id,$videoId);
            return view('Video.openVideoCoach',['videoData'=>$videoData]);
    }
    public function getFilterVideo(Request $request){
        $data = $_POST;
        $user_id = $data['user_id'];
        $videoData = [];
        $videoIdArr = [];
        if(isset($data['selected_tag'])){
            $selectedMediaTags = $data['selected_tag'];
            $videoData = [];
            foreach($selectedMediaTags as $selectedMediaTags){
                // $videoData = DB::table('upload_video_tag')->where('media_taggs_user_id',$user_id)->where('media_taggs_id',$selectedMediaTags)->select('upload_video_tag.upload_video_id')->get();
                $videoData1 = DB::table('upload_video_tag')
                    ->join('upload_video','upload_video.id','upload_video_tag.upload_video_id')
                    ->where('upload_video_tag.media_taggs_user_id',$user_id)
                    ->where('upload_video_tag.media_taggs_id',$selectedMediaTags)
                    ->select('upload_video_tag.*','upload_video.*')->get();
                    if(count($videoData1)>0){
                        if(!in_array($videoData1[0]->id,$videoIdArr)){
                            array_push($videoData,$videoData1[0]);
                            array_push($videoIdArr,$videoData1[0]->id);
                        }else{}
                    }
            }
        }else{
            $videoData = DB::table('upload_video')->where('user_id',$user_id)->get();
        }
        return view('Video.filterVideo',['videoData'=>$videoData]);
    }
}
