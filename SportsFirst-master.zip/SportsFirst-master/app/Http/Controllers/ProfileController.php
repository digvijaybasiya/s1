<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use App\Models\Profile;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class ProfileController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $state = DB::table('tbl_states')->get();
        $user_id = Auth::user()->id;
        if($user_id){
            $userData = (DB::table('users')->where('id', $user_id)->first());
        }else{
            $userData = '';
        }
        return view('Profile.index',[ 'userData'=>$userData,'state'=>$state]);
    }
    public function addProfile(Request $request){
        $data = $_POST;
        $city = '';
        $city = isset($data['city']) ? $data['city'] : '';
        $profileData = [
			"last_name"=>$data['last_name'],
			"DOB"=>$data['DOB'],
			"gender"=>$data['gender'],
			"blood_group"=>$data['blood_group'],
			"city"=>$city,
			"weight"=>$data['weight'],
			"pincode"=>$data['pincode'],
			"state"=>$data['state'],
			"address"=>$data['address'],
			"sports_name"=>$data['sports_name'],
			"position"=>$data['position'],
			"training_days"=>$data['training_days'],
			"user_id"=>$data['user_id']
		];
        $validator = $request->validate([
            'first_name'=>'required'
        ]);
        // update if profile exists or add to profiles
        if(DB::table('profiles')->where('user_id', $data['user_id'])->exists()){
            $userUpdateData = DB::table('users')->where('id', $data['user_id'])->update(["name"=>$data['first_name']]);
            $updateData = DB::table('profiles')->where('user_id', $data['user_id'])->update($profileData);
            if($updateData){
                $response = [
                    'success'=>1,
                    'message'=>'Profile updated successfully'
                ];
            }else{
                $response = [
                    'success'=>0,
                    'message'=>'Profile cannot be updated'
                ];
            }
        }else{
            $addProfile = new Profile($profileData);
            if($addProfile->save()){
                $response = [
                    'success'=>1,
                    'message'=>'Profile added successfully'
                ];
            }else{
                $response = [
                    'success'=>0,
                    'message'=>'Profile cannot be added'
                ];
            }
        }
        return $response;
    }
    public function getcities($state_id){
        $city = DB::table('tbl_cities')->where('state_id',$state_id)->get();
        return response()->json($city);
    }
    public function coachProfile(){
        $athleteName = DB::table('users')->where('user_type',1)->get();
        return view('Profile.coachIndex',['athleteName'=>$athleteName]);
    }
    public function getAthleteData($user_id){
        $userData = (DB::table('users')
            ->leftjoin('profiles','users.id','profiles.user_id')
            ->leftjoin('tbl_states','profiles.state','tbl_states.id')
            ->leftjoin('tbl_cities','profiles.city','tbl_cities.id')
            ->where('users.id', $user_id)
            ->select('profiles.*','users.*','tbl_states.name as state_name','tbl_cities.name as city_name')
            ->first());
        return $userData;
    }
}
?>