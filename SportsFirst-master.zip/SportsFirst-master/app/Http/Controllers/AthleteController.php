<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\Score;
use Illuminate\Support\Facades\Auth;

class AthleteController extends Controller
{
    public function index(){
        return view('Layouts.SelectedAthlete.Athlete_Main');
    }
    public function dashboard(Request $request){
        $athlete_id = $request->id;
        $progressData = $this->get_score($athlete_id);
        return view('SelectedAthlete.athlete_dashboard',['progressData'=>$progressData]);
    }
    public function profile(Request $request,ProfileController $profileController){
        $athlete_id = $request->id;
        $athleteData = $profileController->getAthleteData($athlete_id);
        return view('SelectedAthlete.athlete_profile',['athleteData'=>$athleteData]);
    }
    public function calender(){
        return view('SelectedAthlete.athlete_calender');
    }
    public function displayVideo(Request $request){
        $athlete_id = $request->id;
        $mediaTags = DB::table('media_taggs')->get();
        return view('SelectedAthlete.athlete_display_video',['mediaTags'=>$mediaTags]);
    }
    public function progressCard(){
        $athlete_id = (Auth::user()->user_type == 1 ? Auth::user()->id : (Auth::user()->user_type == 3 ? Auth::user()->athlete_id : ''));
        // $athlete_id = Auth::user()->id;
        $progressData = $this->get_score($athlete_id);
        return view('Score.athlete_progress',['progressData'=>$progressData]);
    }
    public function save_progress(Request $request)
    {
        $data = $_POST;
        $user_id = $data['user_id'];
        $coach_id = Auth::user()->id;
        $store = [
            "score_date"=>$data['score_date'],
            "match_no"=>$data['match_no'],
            "run"=>$data['run'],
            "economy"=>$data['economy'],
            "percentage"=>$data['percentage'],
            "best_avg"=>$data['best_avg'],
            "user_id"=>$data['user_id'],
            "coach_id"=>$coach_id
        ];
        $addScore = new Score($store);
        if($addScore->save()){
            $response = [
                'success'=>1,
                'message'=>'Score added successfully'
            ];
        }else{
            $response = [
                'success'=>0,
                'message'=>'Score cannot be added'
            ];
        }
        return $response;
    }
    public function get_score($athlete_id){
        if(Auth::user()->user_type == 2){
            $athlete_id = $athlete_id;
            $coach_id = Auth::user()->id;
            $scoreData = DB::table('score')->where('user_id',$athlete_id)->where('coach_id',$coach_id)->get();
        }elseif(Auth::user()->user_type == 1){
            $athlete_id = $athlete_id;
            $scoreData = DB::table('score')->where('user_id',$athlete_id)->get();
        }elseif(Auth::user()->user_type == 3){
            $athlete_id = $athlete_id;
            $scoreData = DB::table('score')->where('user_id',$athlete_id)->get();
        }
        return $scoreData;
    }
}
