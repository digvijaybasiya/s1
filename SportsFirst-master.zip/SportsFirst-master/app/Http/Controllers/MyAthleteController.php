<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Storage;
use DataTables;
use Carbon\Carbon;

class MyAthleteController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->app_url= env('APP_URL');
    }
    public function index(){
        return view('MyAthlete.index');
    }
    public function list(Request $request)
    {
        if ($request->ajax())
        {
            $coach_id  = Auth::user()->id;
            // $data = (DB::table('users')->where('coach_id', $coach_id)->get());
            $data = DB::table('users')
                    ->leftjoin('users as parent','users.id','parent.athlete_id')
                    ->where('users.coach_id', $coach_id)
                    ->orWhere('parent.coach_id', $coach_id)
                    ->select('users.name as username','users.user_type','parent.name as parentname','users.id')->get();
            foreach($data as $index => $value){
                if($value->user_type == 3){
                    unset($data[$index]);
                }
            }
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $actionBtn = '<a href="javascript:void(0)" class="edit btn btn-success btn-sm" onclick="athleteView('.$row->id.')">Display</a> ';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
    }
    protected function onSendInvitation(Request $request){
        $appUrl = env('APP_URL');
        try{
            if($request->ajax()){

                $data=$request->post();

                $mail=$data['invite_email'];
                $mail_msg=$data['invite_msg'];

                $user_id=Auth::user()->id;

                if(!empty($mail) && !empty($mail_msg)){

                    $hashId = \Crypt::encryptString($user_id);
                    $hashEmailId = \Crypt::encryptString($mail);

                    $API_KEY="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";

                    $subject = "Verify its you";
                    $to = $mail;
                    $body = "<html><head></head><body><div><h1>Verify Email</h1></div><p>Hi ,</p><p>".$mail_msg."</p><p>Please verify your email by clicking <b><a href='$appUrl/verification/$hashEmailId/$hashId'>Verify Email</a></b> link.</p></body></html>"; 
                    // $body = "<html><head></head><body><div><h1>Invitation to register</h1></div><p>Hi ,</p><p>".$mail_msg."</p><p>Please register yourself on our site by clicking <b><a href='$appUrl/AccountRegister'>Register here</a></b>.</p></body></html>";

                    //echo $body;die;

                    $ch = curl_init();

                    curl_setopt($ch, CURLOPT_URL, 'https://api.sendinblue.com/v3/smtp/email');
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    // curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"$data['name']\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"John Doe\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");

                    $headers = array();
                    $headers[] = 'Accept: application/json';
                    $headers[] = "Api-Key: $API_KEY";
                    $headers[] = 'Content-Type: application/json';
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

                    $result = curl_exec($ch);
                    if (curl_errno($ch)) {
                        $return['error'] =curl_error($ch);
                    }

                    curl_close($ch);

                    $result = json_decode($result, TRUE);  

                    //echo "<pre>"; print_r($result); exit;
                    if(!empty($result['messageId'])){

                        $invite_data=DB::table('invite_notification')->where([['invite_coach_id',$user_id],['invite_email',$mail]])->first();

                        $dataArray=array(
                            'invite_coach_id'=>$user_id,
                            'invite_email'=>$mail,
                            'invite_message'=>$mail_msg,
                            'created_at'=>date('Y-m-d')
                        );

                        if(!empty($invite_data)){
                            DB::table('invite_notification')->where([['invite_coach_id',$user_id],['invite_email',$mail]])->update($dataArray);
                        }else{
                            DB::table('invite_notification')->insert($dataArray);
                        }
            
                        

                        $return['success']="Invitation has been sent";
                    }
                    else{
                        $return['error']="Email Not Sent ";
                    }

                }else{
                    $return['error']='mail id & message is required.';
                }


            }else{
                $return['error']='Not permitted';
            }

            return response()->json($return);

        } catch (Exception $e) {
            return $e->getMessage();
        }
    }
    protected function onSendParentInvitation(Request $request){
        $appUrl = env('APP_URL');
        try{
            if($request->ajax()){

                $data=$request->post();

                $mail=$data['invite_email'];
                $mail_msg=$data['invite_msg'];
                $athlete_id = $data['athlete_id'];

                $user_id=Auth::user()->id;
                // echo json_encode($data);exit;

                if(!empty($mail) && !empty($mail_msg)){

                    $hashId = \Crypt::encryptString($user_id);
                    $selected_hashId = \Crypt::encryptString($athlete_id);
                    $hashEmailId = \Crypt::encryptString($mail);
                    // echo $appUrl . '/verification/' . $hashEmailId . '/' . $hashId . '/' . $selected_hashId;exit;
                    $API_KEY="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";

                    $subject = "Verify its you";
                    $to = $mail;
                    $body = "<html><head></head><body><div><h1>Verify Email</h1></div><p>Hi Parent,</p><p>".$mail_msg."</p><p>Please verify your email by clicking <b><a href='$appUrl/verification/$hashEmailId/$hashId/$selected_hashId'>Verify Email</a></b> link.</p></body></html>"; 
                    // $body = "<html><head></head><body><div><h1>Invitation to register</h1></div><p>Hi ,</p><p>".$mail_msg."</p><p>Please register yourself on our site by clicking <b><a href='$appUrl/AccountRegister'>Register here</a></b>.</p></body></html>";

                    //echo $body;die;

                    $ch = curl_init();

                    curl_setopt($ch, CURLOPT_URL, 'https://api.sendinblue.com/v3/smtp/email');
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                    curl_setopt($ch, CURLOPT_POST, 1);
                    // curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"$data['name']\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");
                    curl_setopt($ch, CURLOPT_POSTFIELDS, "{  \n   \"sender\":{  \n      \"name\":\"Sports First\",\n      \"email\":\"donotreply@sportsfirst.com\"\n   },\n   \"to\":[  \n      {  \n         \"email\":\"$to\",\n         \"name\":\"John Doe\"\n      }\n   ],\n   \"subject\":\"$subject\",\n   \"htmlContent\":\"$body\"\n}");

                    $headers = array();
                    $headers[] = 'Accept: application/json';
                    $headers[] = "Api-Key: $API_KEY";
                    $headers[] = 'Content-Type: application/json';
                    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

                    $result = curl_exec($ch);
                    if (curl_errno($ch)) {
                        $return['error'] =curl_error($ch);
                    }

                    curl_close($ch);

                    $result = json_decode($result, TRUE);  

                    //echo "<pre>"; print_r($result); exit;
                    if(!empty($result['messageId'])){

                        $invite_data=DB::table('invite_notification')->where([['invite_coach_id',$user_id],['invite_email',$mail]])->first();

                        $dataArray=array(
                            'invite_coach_id'=>$user_id,
                            'invite_email'=>$mail,
                            'invite_message'=>$mail_msg,
                            'created_at'=>date('Y-m-d')
                        );

                        if(!empty($invite_data)){
                            DB::table('invite_notification')->where([['invite_coach_id',$user_id],['invite_email',$mail]])->update($dataArray);
                        }else{
                            DB::table('invite_notification')->insert($dataArray);
                        }
            
                        

                        $return['success']="Invitation has been sent";
                    }
                    else{
                        $return['error']="Email Not Sent ";
                    }

                }else{
                    $return['error']='mail id & message is required.';
                }


            }else{
                $return['error']='Not permitted';
            }

            return response()->json($return);

        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    protected function indexVerifyInvitation($hashEmailId,$hashId){
        session(['invite_mail'=>'','invite_coach_id'=>'','selected_athlete_id'=>'']);
        try{

            if(!empty($hashEmailId) && !empty($hashId)){
                $athelete_email_id=\Crypt::decryptString($hashEmailId);
                $coach_id=\Crypt::decryptString($hashId);

                $notification_data=array(
                    'notification_email'=>$athelete_email_id,
                    'notification_coach_id'=>$coach_id
                );

                session(['invite_mail'=>$athelete_email_id,'invite_coach_id'=>$coach_id]);

                $response=array('success'=>'Email account verified.Wait pls,system is redirecting','notification_data'=>$notification_data);
            }else{
                $response=array('error'=>'Email account can not be verified');
            }

            return view('MyAthlete.athleteverify',['response'=>$response]);

        } catch (Exception $e) {
            return $e->getMessage();
        }

        
    }
    protected function indexVerifyParentInvitation($hashEmailId,$hashId,$selected_hashId){
        session(['invite_mail'=>'','invite_coach_id'=>'','selected_athlete_id'=>'']);
        try{

            if(!empty($hashEmailId) && !empty($hashId)){
                $athelete_email_id=\Crypt::decryptString($hashEmailId);
                $coach_id=\Crypt::decryptString($hashId);
                $athlete_id=\Crypt::decryptString($selected_hashId);

                $notification_data=array(
                    'notification_email'=>$athelete_email_id,
                    'notification_coach_id'=>$coach_id
                );

                session(['invite_mail'=>$athelete_email_id,'invite_coach_id'=>$coach_id,'selected_athlete_id'=>$athlete_id]);

                $response=array('success'=>'Email account verified.Wait pls,system is redirecting','notification_data'=>$notification_data);
            }else{
                $response=array('error'=>'Email account can not be verified');
            }

            return view('MyAthlete.athleteverify',['response'=>$response]);

        } catch (Exception $e) {
            return $e->getMessage();
        }

        
    }
}
