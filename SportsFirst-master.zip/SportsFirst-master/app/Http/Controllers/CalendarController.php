<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use App\Models\Calendar;
use App\Models\todoitem;
use App\Models\CrudEvents;
use Illuminate\Support\Facades\Auth;
use App\Models\CalendarSchedule;

class CalendarController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }  

    public function index(Request $request)
    {
        $loggedIn_user = $request->id;
        if($request->ajax()) {  
            $data = CalendarSchedule::whereDate('event_start', '>=', $request->start)
                ->whereDate('event_start',   '<=', $request->end)
                ->where('athlete_id', $loggedIn_user)
                ->get(['id', 'event_name', 'event_location', 'event_start']);
            // $data = todoitem::whereDate('to_do_due_date', '>=', $request->start)
            //     ->whereDate('to_do_due_date',   '<=', $request->end)
            //     ->where('user_id', $loggedIn_user)
            //     ->get(['id', 'to_do_task', 'to_do_due_date', 'user_id']);
             $sample_response_final = [];
            foreach ($data as $key => $value) {
            	
            	$sample_response = array();
            	$sample_response['title'] = $value->event_name;
            	$sample_response['start'] = $value->event_start;
            	$sample_response['end'] = $value->event_start;
                $sample_response['event_location'] = $value->event_location;

            	$sample_response_final[] = $sample_response;
            }
            return json_encode($sample_response_final,true);
             
        }
        return view('SelectedAthlete.athlete_calender');
    }
 
    public function calendarEvents(Request $request)
    {
        $loggedIn_user = Auth::user()->id;
    	switch ($request->type) {
           case 'create':
              $event = todoitem::create([
                  'to_do_task' => $request->to_do_task,
                  'to_do_due_date' => $request->to_do_due_date,
                  'user_id'=>$loggedIn_user
              ]); 
 
              return response()->json($event);
             break;
  
           case 'edit':
              $event = CrudEvents::find($request->id)->update([
                  'event_name' => $request->to_do_task,
                  'event_start' => $request->to_do_due_date,
                  'event_end' => $request->to_do_due_date,
              ]);
 
              return response()->json($event);
             break;
  
           case 'delete':
              $event = CrudEvents::find($request->id)->delete();
  
              return response()->json($event);
             break;
             
           default:
             # ...
             break;
        }
    }
    public function athlete_dashboard_calendar(Request $request)
    {
        if(Auth::user()->user_type == 1)
            $loggedIn_user = Auth::user()->id;
        elseif(Auth::user()->user_type == 3)
            $loggedIn_user = Auth::user()->athlete_id;
        if($request->ajax()) {  
            $data = CalendarSchedule::whereDate('event_start', '>=', $request->start)
            ->whereDate('event_start',   '<=', $request->end)
            ->where('athlete_id', $loggedIn_user)
            ->get(['id', 'event_name', 'event_location', 'event_start']);
            // $data = todoitem::whereDate('to_do_due_date', '>=', $request->start)
            //     ->whereDate('to_do_due_date',   '<=', $request->end)
            //     ->where('user_id', $loggedIn_user)
            //     ->get(['id', 'to_do_task', 'to_do_due_date', 'user_id']);

             $sample_response_final = [];
            foreach ($data as $key => $value) {
            	
            	$sample_response = array();
            	$sample_response['title'] = $value->event_name;
            	$sample_response['start'] = $value->event_start;
            	$sample_response['end'] = $value->event_start;
                $sample_response['event_location'] = $value->event_location;

            	$sample_response_final[] = $sample_response;
            }
            return json_encode($sample_response_final,true);
             
        }
        return view('Calendar.mainCal');
    }
    public function getScheduleModal(Request $request){
        $sd = $request->event_start;
        $se = $request->event_start;
        $type = $request->type;
        return view('Calendar.scheduleModal',['start_date'=>$sd,'start_end'=>$se,'type'=>$type]);
    }
    public function addSchedule(Request $request)
    {
        $data = $_POST;
        $validator = $request->validate([
            'event_name'=>'required',
            'event_location'=>'required'
        ]);
        $coach_id = Auth::user()->id;
    	switch ($request->type) {
           case 'create':
              $event = CalendarSchedule::create([
                  'event_name' => $data['event_name'],
                  'event_location'=>$data['event_location'],
                  'event_start' => date('Y-m-d', strtotime($data['event_start'])),
                  'event_end' => date('Y-m-d', strtotime($data['event_start'])),
                  'athlete_id'=>$data['athlete_id'],
                  'coach_id'=>$coach_id
              ]); 
                return response()->json($event);
             break;
             default:
             # ...
             break;
        }
    }
}
