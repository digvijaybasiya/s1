<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use DataTables;
use Carbon\Carbon;
use App\Models\MediaTaggs;
use Illuminate\Support\Facades\Auth;

class MediaTaggsController extends Controller
{
    public function index()
    {
        return view('MediaTaggs.index');
    }
    public function list(Request $request)
    {
        if ($request->ajax())
        {
            $data = MediaTaggs::latest()->get();
            //echo json_encode($data[0]['id']);exit;
            return Datatables::of($data)
                ->addIndexColumn()
                ->addColumn('action', function($row){
                    $actionBtn = '<a href="javascript:void(0)" class="edit btn btn-success btn-sm" onclick="edit('.$row['id'].')">Edit</a> <a href="javascript:void(0)" class="delete btn btn-danger btn-sm" onclick="deleterecord('.$row['id'].')">Delete</a>';
                    return $actionBtn;
                })
                ->rawColumns(['action'])
                ->make(true);
        }
    }

    public function save(Request $request)
    {
        $data = $_POST;
        $validator = $request->validate(['tag'=>'required']);
        $store = ["name"=>$data['tag']];
        $addToDo = new MediaTaggs($store);
        if($addToDo->save()){
            $response = [
                'success'=>1,
                'message'=>'Tag added successfully'
            ];
        }else{
            $response = [
                'success'=>0,
                'message'=>'Tag cannot be added'
            ];
        }
        return $response;
    }

    public function read(Request $request)
    {
       $data = $_POST; //echo json_encode($data);exit; 
       $result = MediaTaggs::find($data['id']);
       if(!empty($result)){
            $response = [
                'success'=>1,
                'message'=>$result
            ];
        }else{
            $response = [
                'success'=>0,
                'message'=>'record not found'
            ];
        }
        return $response;
    }

    public function update(Request $request)
    {
       $data = $_POST; //echo json_encode($data);exit;
       $updateData = DB::table('media_taggs')->where('id', $data['eid'])->update(["name"=>$data['uptag']]); 
       if($updateData)
       {
            $response = [
                'success'=>1,
                'message'=>'Tag updated successfully'
            ];
        }else{
            $response = [
                'success'=>0,
                'message'=>'Tag cannot be updated'
            ];
        }
        return $response;
    }

    public function delete(Request $request)
    {
        $data = $_POST; //echo json_encode($data);exit; 
        $record = MediaTaggs::find($data['id']);
        $deleted= $record->delete(); 
        if($deleted)
       {
            $response = [
                'success'=>1,
                'message'=>'Tag deleted successfully'
            ];
        }else{
            $response = [
                'success'=>0,
                'message'=>'Tag cannot be delete'
            ];
        }
        return $response;

    }
}
