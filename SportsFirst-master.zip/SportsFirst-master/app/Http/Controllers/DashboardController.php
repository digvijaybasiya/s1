<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Models\todoitem;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $user_id = Auth::user()->id;
        $todayDate = (Carbon::now())->format('Y-m-d');
        $taskToDo = DB::table('todoitem')->where('user_id',$user_id)->get();
        if(Auth::user()->user_type == 1){   // athlete
            $coach_id = Auth::user()->coach_id;
            $contact = DB::table('users')->where('id',$coach_id)->get();
        }else if(Auth::user()->user_type == 2){     // coach
            $coach_id = Auth::user()->id;
            $contact = DB::table('users')->where('coach_id',$coach_id)->get();
        }else if(Auth::user()->user_type == 3){     // coach
            $coach_id = Auth::user()->coach_id;
            $athlete_id = Auth::user()->athlete_id;
            $parent_id = Auth::user()->id;
            $contact = DB::table('users')->where('id',$coach_id)->get();
        }
        return view('Dashboard.dashboard',['taskToDo'=>$taskToDo,'user_id'=>$user_id,'contact'=>$contact]);
    }
    public function scheduleChange(Request $request){
        $todayDate = (Carbon::now())->format('Y-m-d');
        $user_id = Auth::user()->id;
        if($request->event == 'today'){
            if(Auth::user()->user_type == 1){
                $tasktodisplay = DB::table('calendar_schedules')
                ->join('users','users.id','calendar_schedules.coach_id')
                ->where('calendar_schedules.event_start',$todayDate)
                ->where('calendar_schedules.athlete_id',$user_id)
                ->select('users.name as coach_name','calendar_schedules.event_location','calendar_schedules.event_start','calendar_schedules.event_name','calendar_schedules.event_start')
                ->get();
            }elseif(Auth::user()->user_type == 2){
                $tasktodisplay = DB::table('calendar_schedules')
                ->join('users','users.id','calendar_schedules.athlete_id')
                ->where('calendar_schedules.event_start',$todayDate)
                ->where('calendar_schedules.coach_id',$user_id)
                ->select('users.name as athlete_name','calendar_schedules.event_location','calendar_schedules.event_start','calendar_schedules.event_name','calendar_schedules.event_start')
                ->get();
            }elseif(Auth::user()->user_type == 3){
                $user_id = Auth::user()->athlete_id;
                $tasktodisplay = DB::table('calendar_schedules')
                    ->join('users','users.id','calendar_schedules.coach_id')
                    ->where('calendar_schedules.event_start',$todayDate)
                    ->where('calendar_schedules.athlete_id',$user_id)
                    ->select('users.name as coach_name','calendar_schedules.event_location','calendar_schedules.event_start','calendar_schedules.event_name','calendar_schedules.event_start')
                    ->get();
            }
            // $tasktodisplay = DB::table('todoitem')->where('to_do_due_date',$todayDate)->where('user_id',$user_id)->get();
        }else{
            if(Auth::user()->user_type == 1){
                $tasktodisplay = DB::table('calendar_schedules')
                ->join('users','users.id','calendar_schedules.coach_id')
                ->where('calendar_schedules.event_start','>',$todayDate)
                ->where('calendar_schedules.athlete_id',$user_id)
                ->select('users.name as coach_name','calendar_schedules.event_location','calendar_schedules.event_start','calendar_schedules.event_name','calendar_schedules.event_start')
                ->get();
            }elseif(Auth::user()->user_type == 2){
                $tasktodisplay = DB::table('calendar_schedules')
                ->join('users','users.id','calendar_schedules.athlete_id')
                ->where('calendar_schedules.event_start','>',$todayDate)
                ->where('calendar_schedules.coach_id',$user_id)
                ->select('users.name as athlete_name','calendar_schedules.event_location','calendar_schedules.event_start','calendar_schedules.event_name','calendar_schedules.event_start')
                ->get();
            }elseif(Auth::user()->user_type == 3){
                $user_id = Auth::user()->athlete_id;
                $tasktodisplay = DB::table('calendar_schedules')
                    ->join('users','users.id','calendar_schedules.coach_id')
                    ->where('calendar_schedules.event_start','>',$todayDate)
                    ->where('calendar_schedules.athlete_id',$user_id)
                    ->select('users.name as coach_name','calendar_schedules.event_location','calendar_schedules.event_start','calendar_schedules.event_name','calendar_schedules.event_start')
                    ->get();
            }
            // $tasktodisplay = DB::table('todoitem')->where('to_do_due_date','>',$todayDate)->where('user_id',$user_id)->get();
        }
        return view('Dashboard.custom_schedule',['tasktodisplay'=>$tasktodisplay]);
    }
    public function addToDoItem(Request $request){
        $data = $_POST;
        $addToDoData = [
			"to_do_task"=>$data['to_do_task'],
			"to_do_due_date"=>$data['to_do_due_date'],
			"user_id"=>$data['user_id']
        ];
        $validator = $request->validate([
            'to_do_task'=>'required',
            'to_do_due_date'=>'required'
        ]);
        $addToDo = new todoitem($addToDoData);
        if($addToDo->save()){
            $response = [
                'success'=>1,
                'message'=>'Task added successfully'
            ];
        }else{
            $response = [
                'success'=>0,
                'message'=>'Task cannot be added'
            ];
        }
        return $response;
    }
    public function getToDo(){
        $user_id = Auth::user()->id;
        $taskToDo = DB::table('todoitem')->where('user_id',$user_id)->get();
        return $taskToDo;
    }
    public function openChatModal(Request $request){
        $data = $_POST;
        $user_data = DB::table('users')->where('id',$data['receiver_id'])->first();
        return view('Dashboard.chatModal',['data'=>$user_data]);
    }
    public function getChildAthlete(){
        $athlete_id = Auth::user()->athlete_id;
        $childAthlete = DB::table('users')->where('id',$athlete_id)->where('user_type',1)->get();
        return $childAthlete;
    }
}