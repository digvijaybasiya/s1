<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('Auth.login');
});
// Route::get('/register', function () {
//     return view('Auth.register');
// });
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/register_success', [App\Http\Controllers\HomeController::class, 'register_success'])->name('register_success');
Route::get('/profile', [App\Http\Controllers\ProfileController::class, 'index'])->name('profile');
Route::post('/addProfile', [App\Http\Controllers\ProfileController::class, 'addProfile'])->name('addProfile');
Route::get('/verify/{hashId}/{id}', [App\Http\Controllers\Auth\RegisterController::class, 'verify_email'])->name('verify');
Route::get('login', [App\Http\Controllers\Auth\CustomLoginController::class, 'index'])->name('login');
Route::post('loginCustom', [App\Http\Controllers\Auth\CustomLoginController::class, 'customLogin'])->name('loginCustom');
Route::get('/getCities/{id}', [App\Http\Controllers\ProfileController::class, 'getcities'])->name('getcities');
Route::get('/dashboard', [App\Http\Controllers\DashboardController::class, 'index'])->name('dashboard');
Route::post('/addToDoItem', [App\Http\Controllers\DashboardController::class, 'addToDoItem'])->name('addToDoItem');
Route::get('/getToDo', [App\Http\Controllers\DashboardController::class, 'getToDo'])->name('getToDo');
Route::get('/getAuthUser', [App\Http\Controllers\HomeController::class, 'getAuthUser'])->name('getAuthUser');
Route::get('/viewprofile', [App\Http\Controllers\ProfileController::class, 'coachProfile'])->name('viewprofile');
Route::get('/getAthleteData/{id}', [App\Http\Controllers\ProfileController::class, 'getAthleteData'])->name('getAthleteData');
Route::get('/videos', [App\Http\Controllers\UploadVideoController::class, 'index'])->name('videos');
Route::post('/upload/video', [App\Http\Controllers\UploadVideoController::class, 'upload'])->name('upload/video');
Route::get('/displayVideo', [App\Http\Controllers\UploadVideoController::class, 'displayVideo'])->name('displayVideo');
Route::get('/AccountRegister', [App\Http\Controllers\NewRegisterController::class, 'index'])->name('AccountRegister');
//---------------------- Media Taggs ----------------------------------
Route::get('/media/taggs', [App\Http\Controllers\MediaTaggsController::class, 'index'])->name('/media/taggs');
Route::get('/media/taggs/fetch', [App\Http\Controllers\MediaTaggsController::class, 'list'])->name('/media/taggs/fetch');
Route::post('/media/taggs/save', [App\Http\Controllers\MediaTaggsController::class, 'save'])->name('/media/taggs/save');
Route::post('/media/taggs/read', [App\Http\Controllers\MediaTaggsController::class, 'read'])->name('/media/taggs/read');
Route::post('/media/taggs/update', [App\Http\Controllers\MediaTaggsController::class, 'update'])->name('/media/taggs/update');
Route::post('/media/taggs/delete', [App\Http\Controllers\MediaTaggsController::class, 'delete'])->name('/media/taggs/delete');

//---------------------- Media Taggs ----------------------------------
Route::get('/getAthletePracticeVideo/{id}', [App\Http\Controllers\UploadVideoController::class, 'getAthletePracticeVideo'])->name('getAthletePracticeVideo');
//---------------------- My Athlete ----------------------------------
Route::get('/myAthlete', [App\Http\Controllers\MyAthleteController::class, 'index'])->name('myAthlete');
Route::get('/myAthlete/fetch', [App\Http\Controllers\MyAthleteController::class, 'list'])->name('/myAthlete/fetch');
//---------------------- My Athlete ----------------------------------
//---------------------- Selected Athlete ----------------------------------
Route::get('/athlete/{id}', [App\Http\Controllers\AthleteController::class, 'index'])->name('athlete');
Route::get('/athlete/{id}/dashboard', [App\Http\Controllers\AthleteController::class, 'dashboard'])->name('athlete/dashboard');
Route::get('/athlete/{id}/profile', [App\Http\Controllers\AthleteController::class, 'profile'])->name('athlete/profile');
Route::get('/athlete/{id}/calender', [App\Http\Controllers\AthleteController::class, 'calender'])->name('athlete/calender');
Route::get('/athlete/{id}/videos', [App\Http\Controllers\AthleteController::class, 'videos'])->name('athlete/videos');
Route::get('/athlete/{id}/displayVideo', [App\Http\Controllers\AthleteController::class, 'displayVideo'])->name('athlete/displayVideo');
Route::get('/athlete/{id}/calendar', [App\Http\Controllers\CalendarController::class, 'index'])->name('athlete/calendar');
//---------------------- Selected Athlete ----------------------------------
//---------------------- Calendar ----------------------------------
Route::get('calendar', [App\Http\Controllers\CalendarController::class, 'athlete_dashboard_calendar'])->name('calendar');
Route::post('calendar-crud-ajax', [App\Http\Controllers\CalendarController::class, 'calendarEvents']);
Route::post('addSchedule', [App\Http\Controllers\CalendarController::class, 'addSchedule'])->name('addSchedule');
Route::post('getScheduleModal/{id}', [App\Http\Controllers\CalendarController::class, 'getScheduleModal'])->name('getScheduleModal');
//---------------------- Calendar ----------------------------------
Route::post('scheduleChange', [App\Http\Controllers\DashboardController::class, 'scheduleChange'])->name('scheduleChange');
Route::get('/verification/{hashId}/{id}', [App\Http\Controllers\MyAthleteController::class, 'indexVerifyInvitation'])->withoutMiddleware(['auth'])->name('verify_invite');

Route::post('/atheletes_invite', [App\Http\Controllers\MyAthleteController::class, 'onSendInvitation']);
Route::get('/progressCard', [App\Http\Controllers\AthleteController::class, 'progressCard'])->name('progressCard');
Route::post('/progressCard/save', [App\Http\Controllers\AthleteController::class, 'save_progress'])->name('/progressCard/save');
Route::get('/openVideo/{videoid}', [App\Http\Controllers\UploadVideoController::class, 'athlete_openVideo'])->name('openVideo');
Route::get('/athlete/{id}/openVideo/{videoid}', [App\Http\Controllers\UploadVideoController::class, 'coach_openVideo'])->name('athlete/openVideo');
Route::post('/openChatModal', [App\Http\Controllers\DashboardController::class, 'openChatModal'])->name('openChatModal');
Route::post('/getFilterVideo/{id}', [App\Http\Controllers\UploadVideoController::class, 'getFilterVideo'])->name('getFilterVideo');
Route::post('/parent_invite', [App\Http\Controllers\MyAthleteController::class, 'onSendParentInvitation']);
Route::get('/verification/{hashId}/{id}/{selected_id}', [App\Http\Controllers\MyAthleteController::class, 'indexVerifyParentInvitation'])->withoutMiddleware(['auth']);
Route::get('/getChildAthlete', [App\Http\Controllers\DashboardController::class, 'getChildAthlete'])->name('getChildAthlete');