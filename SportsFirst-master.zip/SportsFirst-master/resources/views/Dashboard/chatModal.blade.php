{{-- <div class="modal fade" id="chatModal" tabindex="-1" aria-hidden="true"> --}}
    <style>
        .pclass{
            background-color: #e7e6e6;
            padding-top: 1%;
            width: 80%;
            height: 20%;
            padding-left: 1%;
        }
        .receiverpclass{
            float: left;
        }
        .senderpclass{
            float: right;
        }
        .datepclass{
            padding-left: 70%;
            font-size: 12px;
        }
    </style>
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
        <div class="modal-header" style="border-bottom: 1px solid #d9dee3;">
            <img src="../assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" style="padding-bottom:3%;"/>
            <h6 class="modal-title" id="modalScrollableTitle" style="padding-left:2%">{{ucfirst($data->name)}}
                {{-- <p id="modalScrollableTitle" style="color:#646464;">{{Auth::user()->user_type == 1 ? 'Coach' : 'Athlete'}}</p></h6> --}}
                <p id="modalScrollableTitle" style="color:#646464;">{{$data->user_type == 2 ? 'Coach' : ($data->user_type == 1 ? 'Athlete' : 'Parent')}}</p></h6>
            <button
            type="button"
            class="btn-close"
            data-bs-dismiss="modal"
            aria-label="Close"
            ></button>
        </div>
        <div class="modal-body" style="height: 300px;">
            <div id="allMessages" style="overflow-y: scroll;height: 90%;">
            </div>
        </div>
        <div class="modal-footer" style="padding:0.25rem 0.5rem 1.5rem">
            <input type="text" value="" id="messageInput" placeholder="Type Here" style="padding-left: 2%;width:90%;border: 1px solid #E5E5E5;">
            <input type="hidden" id="sender_id" placeholder="Enter sender id" value="{{Auth::user()->id}}">
            <input type="hidden" id="receiver_id" placeholder="Enter receiver id" value="{{$data->id}}">
            <button type="button" onclick="sendFeedback()" style="border:none;background-color: transparent;">
                <i class='bx bxs-send' style="color: #C4C4C4;"></i>
            </button>
            <p><label style="color: red" id="errMsg"></label></p>
        </div>
        </div>
    </div>
{{-- </div> --}}
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> --}}
<script>
    var firebaseConfig = {
        apiKey: "AIzaSyA0id4oceCIdLEkQVINFptZxZcXHff2f-Y",
        authDomain: "sportsfirst-d8785.firebaseapp.com",
        databaseURL: "https://sportsfirst-d8785-default-rtdb.firebaseio.com/",
        projectId: "sportsfirst-d8785",
        storageBucket: "sportsfirst-d8785.appspot.com",
        messagingSenderId: "240938738821",
        appId: "1:240938738821:web:e25aa98034016039d7b5ec"
    };
    if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
    }
    // firebase.initializeApp(firebaseConfig);
    var database = firebase.database();
    getFeedback();
    function sendFeedback(){
        if(document.getElementById("messageInput").value == ''){
            $('#errMsg').text('Please add message');
        }else{
            $('#errMsg').text('');
            var messagesContainer = document.getElementById("allFeedback");
            var coachIdContainer = document.getElementById("coachIds");
            var athleteIdContainer = document.getElementById("athleteIds");
            var messageInput = document.getElementById("messageInput");
            var sender_idInput = document.getElementById("sender_id");
            var receiver_idInput = document.getElementById("receiver_id");
            var form = document.querySelector("form");
            var message = messageInput.value;
            var sender_id = sender_idInput.value;
            var receiver_id = receiver_idInput.value;
            console.log(sender_id)

            database.ref("messages").push({
                message: message,
                sender_id:sender_id,
                receiver_id:receiver_id,
                start_time: Date.now()
            });
            messageInput.value = "";
            database.ref("messages").orderByKey().limitToLast(1).on('child_added',function(snapshot) {
                console.log('new record', snapshot.val());
                getUpdatedMsg(snapshot.val())
            });
        }
    }
    async function getFeedback(){
        var senderMsg = [];
        var receiverMsg = [];
        var sender_idInput = document.getElementById("sender_id").value;
        var receiver_idInput = document.getElementById("receiver_id").value;
        await database.ref("messages").on("child_added", function(snapshot) {
            if(snapshot.val().sender_id == sender_idInput){
                senderMsg.push(snapshot.val());
            }
            if(snapshot.val().sender_id == receiver_idInput){
                receiverMsg.push(snapshot.val());
            }
        });
        setTimeout(function() {
            // var a = senderMsg.sort((a, b) => a.value - b.value);
            var mergeArr = senderMsg.concat(receiverMsg);
            console.log(mergeArr)
            var a = mergeArr.sort((a, b) => a.start_time - b.start_time);
            console.log(a)
            mergeArr.forEach(e=>{
                var message = e.message;
                var messageElement = document.createElement("p");
                if(e.sender_id == sender_idInput){
                    messageElement.className = 'pclass ' + 'senderpclass';
                }
                else if(e.sender_id == receiver_idInput){
                    messageElement.className = 'pclass ' + 'receiverpclass';
                }
                messageElement.innerHTML = message;
                $('#allMessages').append(messageElement)
                var validDate = convertDate(e.start_time);
                var dateElement = document.createElement("p");
                dateElement.className = 'datepclass';
                dateElement.innerHTML = validDate;
                messageElement.append(dateElement);
            })
        },2000)
    }
    function getUpdatedMsg(msg){
        var sender_idInput = document.getElementById("sender_id").value;
        var receiver_idInput = document.getElementById("receiver_id").value;
        mergeArr = [];
        if(msg.sender_id == sender_idInput){
            mergeArr.push(msg);
        }
        if(msg.sender_id == receiver_idInput){
            mergeArr.push(msg);
        }
            mergeArr.forEach(e=>{
                var message = e.message;
                var messageElement = document.createElement("p");
                if(e.sender_id == sender_idInput){
                    messageElement.className = 'pclass ' + 'senderpclass';
                }
                else if(e.sender_id == receiver_idInput){
                    messageElement.className = 'pclass ' + 'receiverpclass';
                }
                messageElement.innerHTML = message;
                $('#allMessages').append(messageElement)
                var validDate = convertDate(e.start_time);
                var dateElement = document.createElement("p");
                dateElement.className = 'datepclass';
                dateElement.innerHTML = validDate;
                messageElement.append(dateElement);
            })
    }
    function convertDate(timestamp){
        var d = new Date(timestamp);
        var month1 = (d.getMonth()) + 1;
        var month = month1.toString().length === 1 ? "0" + month1 : month1;
        var minutes1 = d.getMinutes();
        var minutes = minutes1.toString().length === 1 ? "0" + minutes1 : minutes1;
        var hours1 = d.getHours();
        var hours = hours1.toString().length === 1 ? "0" + hours1 : hours1;
        var date1 = d.getDate();
        var date = date1.toString().length === 1 ? "0" + date1 : date1;
        var year1 = d.getFullYear();
        var year = year1.toString().length === 1 ? "0" + year1 : year1;
        var validDate = date + '/' + month + '/' + year + ' ' + hours + ':' + minutes + ' ' + (d.getHours() >= 12 ? "PM" : "AM")
        return validDate;
    }
</script>