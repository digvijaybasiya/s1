@extends('Layouts.main')
@section('content')
<div class="layout-page">
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y custom-container">
            <div class="row">
                <div class="col-lg-8 order-0">
                    @if(Auth::user()->user_type == 1 || Auth::user()->user_type == 3)
                    <div class="row mb-5 custom-right-row-8">
                        <div class="col-md-6 col-lg-4">
                            <div class="card mb-3 custom_card_mb-3">
                            <div class="card-body">
                                <h6 class="card-title custom_h6">Total Run</h6>
                                <p class="card-text custom_h6">219</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="card mb-3 custom_card_mb-3">
                            <div class="card-body">
                                <h6 class="card-title custom_h6">Average strike rate</h6>
                                <p class="card-text custom_h6">219</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <div class="card mb-3 custom_card_mb-3">
                            <div class="card-body">
                                <h6 class="card-title custom_h6">Best Score</h6>
                                <p class="card-text custom_h6">219</p>
                            </div>
                            </div>
                        </div>
                    </div>
                    @endif
                    <div class="row mb-5 custom-right-row-8">
                        <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
                            <div class="row">
                                <div class="col-md-6 col-lg-6">
                                    @if(Auth::user()->user_type == 3)<h6 class="custom_schedule_h6 custom_h6">Today's Schedule</h6>
                                    @else
                                    <h6 class="custom_schedule_h6 custom_h6">Your Schedule</h6>
                                    @endif
                                </div>
                                <div class="col-md-6 col-lg-6">
                                      <div>
                                          <ul class="nav nav-pills mb-3 custom-toggle" role="tablist">
                                              <li class="nav-item">
                                              <button
                                                  type="button"
                                                  class="nav-link active custom-toggle-btn"
                                                  role="tab"
                                                  data-bs-toggle="tab"
                                                  data-bs-target="#navs-pills-top-home"
                                                  aria-controls="navs-pills-top-home"
                                                  aria-selected="true"
                                                  onclick="schedulebtn('today')"
                                              >
                                                  Today
                                              </button>
                                              </li>
                                              <li class="nav-item">
                                              <button
                                                  type="button"
                                                  class="nav-link custom-toggle-btn"
                                                  role="tab"
                                                  data-bs-toggle="tab"
                                                  data-bs-target="#navs-pills-top-profile"
                                                  aria-controls="navs-pills-top-profile"
                                                  aria-selected="false"
                                                  onclick="schedulebtn('upcoming')"
                                              >
                                                  Upcoming
                                              </button>
                                              </li>
                                          </ul>
                                      </div>
                                </div>
                            </div>
                            <div id="scheduleId"></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 order-1 bg-menu-theme custom-right-col-4">
                    @if(Auth::user()->user_type != 3)
                    <div class="row mb-5 custom-right-row-4">
                        <h5>Add to-do item <i class='add-icon-color bx bxs-plus-circle'
                            class="btn btn-primary"
                            data-bs-toggle="modal"
                            data-bs-target="#modalCenter" style=""></i></h5>
                        <ul class="custom-ul-scroll nav nav-pills mb-3 custom-toggle" role="tablist">
                            @if(count($taskToDo) > 0)
                                @foreach ($taskToDo as $taskToDo)
                                    <li class="nav-item">{{$taskToDo->to_do_task}}</li>
                                @endforeach
                            @else
                                <input type="text" name="" id="" class="form-control custom-noitem" placeholder="No to do items yet" readonly>
                                {{-- <li class="nav-item">No to do items yet</li> --}}
                            @endif
                        </ul>
                    </div>
                    @endif
                    <div class="row mb-5">
                        @if(Auth::user()->user_type == 3)<h5>Coach's Contact</h5>
                        @else<h5>Comment & Replies</h5>
                        @endif
                        <ul class="nav nav-pills mb-3 custom-toggle" role="tablist">
                            @foreach ($contact as $contact)
                                <li>
                                    <img src="../assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle" />
                                    <strong><a onclick="openChatModal({{$contact->id}})" class="custom-chat-contact">{{ucfirst($contact->name)}}</a></strong>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                </div>
            </div>
          </div>
    </div>
</div>
<!-- Modal -->
<div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Add-to do Item</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="POST" id="addtodoitem" action="{{ route('addToDoItem') }}" enctype="multipart/form-data">
            {{-- @csrf --}}
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <div class="modal-body">
                <div class="row">
                    <div class="col mb-3">
                    <label for="nameWithTitle" class="form-label">Task to do</label>
                    <input type="text" id="to_do_task" name="to_do_task" class="form-control" placeholder="Enter Task To Do"/>
                    <input type="hidden" id="user_id" name="user_id" value="{{$user_id}}" class="form-control"/>
                    </div>
                </div>
                <div class="row g-2">
                    <div class="col mb-0">
                    <label for="dobWithTitle" class="form-label">Due Date</label>
                    <input type="date" id="to_do_due_date" name="to_do_due_date" class="form-control" placeholder="DD / MM / YY"/>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="button" onclick="saveToDo()" value="Add Item" class="btn btn-primary addtodoitemBtn" id="addtodoitemBtn"/>
            </div>
        </form>
    </div>
    </div>
</div>
<div class="modal fade" id="modalChat" tabindex="-1" aria-hidden="true">
</div>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.4/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.4/firebase-database.js"></script>
<script>
    $(document).ready(function () {
        $(".carousel .carousel-inner .carousel-item").first().addClass("active");
        schedulebtn('today');
    });
    function saveToDo(){
        var fd = new FormData(document.getElementById('addtodoitem'));
        $.ajax({    //create an ajax request to display.php
            type: 'POST',
            url: '/addToDoItem', 
            data: fd,
            contentType: false,
            processData: false,   
            cache: false, 
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function(response)
            {                    
                $('#modalCenter').modal('toggle');
                alert(response.message);
                $.ajax({    //create an ajax request to display.php
                    type: 'GET',
                    url: '/getToDo',
                    success: function(response){
                        console.log(response)
                    },
                    error:function(error){
                        console.log("get",error)
                    }
                });
            },
            error:function(error){
                console.log("error",error)
            }
        })
    }
    function schedulebtn(event){
        $.ajax({    //create an ajax request to display.php
            type: 'POST',
            url: '/scheduleChange',
            data: {event:event},
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function(response)
            {                    
                $('#scheduleId').html(response);
            }
        });
    }
    function openChatModal(receiver_id){
        $.ajax({    //create an ajax request to display chat modal
            type: 'POST',
            url: '/openChatModal',  
            data: {receiver_id:receiver_id},
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function(response)
            {
                $('#modalChat').html(response);
                $('#modalChat').modal('toggle');
            },
            error:function(error){
                console.log("error",error)
            }
        })
    }
</script>