@if (count($tasktodisplay)<=0)
<div>
    Don't have any events yet
</div>
@else
<div class="row col-md-6 col-lg-8 carousel carousel-dark slide carousel-fade" id="carouselExample-cf" data-bs-ride="carousel">
    <div class="carousel-inner">
        @foreach ($tasktodisplay as $carousel_tasktodisplay)
            <div class="col-md-6 col-lg-8 carousel-item">
                <div class="card custom-card">
                    <div class="card-body custom-card-body">
                        <div class="card-title row">
                            <div class="col-lg-3">
                                <img src="../assets/img/avatars/1.png" alt class="w-px-40 h-auto rounded-circle custom-slider-img" /></div>
                            <div class="col-lg-9">
                                <label class="label-padding">{{Auth::user()->user_type == 1 || Auth::user()->user_type == 3 ? ucfirst($carousel_tasktodisplay->coach_name) : ucfirst($carousel_tasktodisplay->athlete_name)}}</label><br/>
                                <label class="label-sub-padding">{{ucfirst($carousel_tasktodisplay->event_name)}}</label>
                            </div>
                        </div>
                    </div>
                    <div class="custom_divider">
                        <div class="card-body">
                            <div class="card-title">
                                <div class="row">
                                    <div class="col-lg-3"><p><i class='bx custom-bx bx-time-five bx-md'></i></p></div>    
                                    <div class="col-lg-9"><label class="label-sub-padding">{{$carousel_tasktodisplay->event_start}}</label></div>
                                </div>
                                <div class="row">
                                    <div class="col-lg-3"><p><i class='bx custom-bx bx-current-location bx-md'></i></p></div>    
                                    <div class="col-lg-9"><label class="label-sub-padding">{{ucfirst($carousel_tasktodisplay->event_location)}}</label></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
    @if (count($tasktodisplay)>1)
        <a class="carousel-control-prev" href="#carouselExample-cf" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExample-cf" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </a>
    @endif
</div>
@endif
<script>
    $(document).ready(function () {
        $(".carousel .carousel-inner .carousel-item").first().addClass("active");
    });
</script>