<div class="row mb-5">
    @if (count($videoData)<=0)
        <div class="col-md-6 col-lg-4" style="width: 30.333333%;"></div>
        <div class="col-md-6 col-lg-4" style="width: 30.333333%;">
            <h4>Don't have any videos yet</h4>
        </div>
        <div class="col-md-6 col-lg-4" style="width: 30.333333%;">
        </div>
        @else
        @foreach ($videoData as $videoData)
        <div class="col-md-6 col-lg-4" style="width: 30.333333%;">
            <div class="card mb-4">
            <div class="card-body" style="padding: 0">
            @if(Auth::user()->user_type == 2)
                <a href="{{url('athlete/'.request()->id.'/openVideo'.'/'.$videoData->id.'/')}}">
                    <video style="width: 277px;height: 156px;border-radius: 4px;" controls>
                    <source src="{{$videoData->video_url}}" alt="./assets/img/defaultVideo.mp4" type="video/mp4">
                    </video>
                </a>
            @else
                {{-- <a href="{{url('/openVideo/'.$videoData->id.'/')}}"> --}}
                <a>
                <video style="width: 277px;height: 156px;border-radius: 4px;" controls>
                <source src="{{$videoData->video_url}}" alt="./assets/img/defaultVideo.mp4" type="video/mp4">
                </video>
            </a>
            @endif
            </div>
            </div>
        </div>    
        @endforeach
    @endif
</div>