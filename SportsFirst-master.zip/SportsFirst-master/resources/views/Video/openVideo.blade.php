
<head>
    <style>
        .pclass{
            background-color: #e7e6e6;
            padding-top: 2%;
            width: 80%;
            height: 11%;
            padding-left: 2%;
        }
        .receiverpclass{
            float: left;
        }
        .senderpclass{
            float: right;
        }
        .datepclass{
            padding-left: 51%;
            font-size: 12px;
            padding-top: 3%;
        }
    </style>
</head>
<div class="layout-page">
  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xxl {{(request()->id == '') ? 'custom-right-row-8' : ''}}">
                <div class="row mb-5" id="videoId">
                    <div class="col-lg-8 col-md-4 order-1">
                        <div class="row mb-5" id="videoId">
                            @foreach ($videoData as $videoData)
                                <div class="col-md-6 col-lg-8" style="width: 30.333333%;">
                                    <div class="card mb-4" style="height:155px">
                                    <div class="card-body" style="padding: 0">
                                        <video style="width: 277px;height: 156px;border-radius: 4px;" controls>
                                        <source src="{{$videoData->video_url}}" alt="./assets/img/defaultVideo.mp4" type="video/mp4">
                                        </video>
                                    </div>
                                    </div>
                                </div>    
                            @endforeach
                            @if (Auth::user()->user_type != 3)
                            @if (request()->id != '')
                            <form>
                                <input type="text" id="messageInput" class="form-control" placeholder="Add comment">
                                <label style="color: red" id="errMsg"></label>
                                <input type="hidden" id="sender_id" placeholder="Enter your coach id" value="{{Auth::user()->id}}">
                                <input type="hidden" id="receiver_id" placeholder="Enter your athlete id" value="{{request()->id}}">
                                <input type="hidden" id="video_id" placeholder="Enter your athlete id" value="{{request()->videoid}}">
                                <button type="button" class="btn btn-primary" onclick="sendFeedback()" style="float: right;margin-top: 2%;">Post</button>
                            </form>
                            @else
                            <form>
                                <input type="text" id="messageInput" class="form-control" placeholder="Add comment">
                                <label style="color: red" id="errMsg"></label>
                                <input type="hidden" id="sender_id" placeholder="Enter your athlete id" value="{{Auth::user()->id}}">
                                <input type="hidden" id="receiver_id" placeholder="Enter your coach id" value="{{Auth::user()->coach_id}}">
                                <input type="hidden" id="video_id" placeholder="Enter your athlete id" value="{{request()->videoid}}">
                                <button type="button" class="btn btn-primary" onclick="sendFeedback()" style="float: right;margin-top: 2%;">Post</button>
                            </form>
                            @endif
                            @else
                            <form>
                                <input type="hidden" id="sender_id" placeholder="Enter your coach id" value="{{Auth::user()->athlete_id}}">
                                <input type="hidden" id="receiver_id" placeholder="Enter your athlete id" value="{{Auth::user()->coach_id}}">
                                <input type="hidden" id="video_id" placeholder="Enter your athlete id" value="{{request()->videoid}}">
                            </form>
                            @endif
                        </div>
                        <div class="row mb-5" id="videoId">
                            <div class="col-md-6 col-lg-4" style="width: 30.333333%;">
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-4 order-1">
                        <h3>Feedbacks</h3>
                        <div id="allFeedback" style="overflow-y: scroll;{{Auth::user()->user_type == 3 ? 'height: 115%;' : 'height: 90%;'}}">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.4/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.14.4/firebase-database.js"></script>
<script>
    var firebaseConfig = {
        apiKey: "AIzaSyA0id4oceCIdLEkQVINFptZxZcXHff2f-Y",
        authDomain: "sportsfirst-d8785.firebaseapp.com",
        databaseURL: "https://sportsfirst-d8785-default-rtdb.firebaseio.com/",
        projectId: "sportsfirst-d8785",
        storageBucket: "sportsfirst-d8785.appspot.com",
        messagingSenderId: "240938738821",
        appId: "1:240938738821:web:e25aa98034016039d7b5ec"
    };
    firebase.initializeApp(firebaseConfig);
    var database = firebase.database();
    if(document.getElementById("sender_id") != null)
        getFeedback();

    function sendFeedback(){
        if(document.getElementById("messageInput").value == ''){
            $('#errMsg').text('Please add comment');
        }else{
            $('#errMsg').text('');
            var messagesContainer = document.getElementById("allFeedback");
            var coachIdContainer = document.getElementById("coachIds");
            var athleteIdContainer = document.getElementById("athleteIds");
            var messageInput = document.getElementById("messageInput");
            var sender_idInput = document.getElementById("sender_id");
            var receiver_idInput = document.getElementById("receiver_id");
            var video_idInput = document.getElementById("video_id");
            var form = document.querySelector("form");
            var message = messageInput.value;
            var sender_id = sender_idInput.value;
            var receiver_id = receiver_idInput.value;
            var video_id = video_idInput.value;
            console.log(sender_id)

            database.ref("allFeedback").push({
                message: message,
                sender_id:sender_id,
                receiver_id:receiver_id,
                video_id:video_id,
                start_time: Date.now()
            });
            messageInput.value = "";
            database.ref("allFeedback").orderByKey().limitToLast(1).on('child_added',function(snapshot) {
                // console.log('new record', snapshot.val());
                getUpdatedMsg(snapshot.val())
            });
        }
    }
    async function getFeedback(){
        var senderMsg = [];
        var receiverMsg = [];
        var sender_idInput = document.getElementById("sender_id").value;
        var receiver_idInput = document.getElementById("receiver_id").value;
        var video_idInput = document.getElementById("video_id").value;
        await database.ref("allFeedback").on("child_added", function(snapshot) {
            if(snapshot.val().video_id == video_idInput){
                if(snapshot.val().sender_id == sender_idInput){
                    senderMsg.push(snapshot.val());
                }
                if(snapshot.val().sender_id == receiver_idInput){
                    receiverMsg.push(snapshot.val());
                }
            }
        });
        setTimeout(function() {
            // var a = senderMsg.sort((a, b) => a.value - b.value);
            var mergeArr = senderMsg.concat(receiverMsg);
            console.log(mergeArr)
            var a = mergeArr.sort((a, b) => a.start_time - b.start_time);
            console.log(a)
            mergeArr.forEach(e=>{
                var message = e.message;
                var messageElement = document.createElement("p");
                if(e.sender_id == sender_idInput){
                    messageElement.className = 'pclass ' + 'senderpclass';
                }
                else if(e.sender_id == receiver_idInput){
                    messageElement.className = 'pclass ' + 'receiverpclass';
                }
                messageElement.innerHTML = message;
                $('#allFeedback').append(messageElement)
                var validDate = convertDate(e.start_time);
                var dateElement = document.createElement("p");
                dateElement.className = 'datepclass';
                dateElement.innerHTML = validDate;
                messageElement.append(dateElement);
            })
        },2000)
    }
    function getUpdatedMsg(msg){
        var sender_idInput = document.getElementById("sender_id").value;
        var receiver_idInput = document.getElementById("receiver_id").value;
        mergeArr = [];
        if(msg.sender_id == sender_idInput){
            mergeArr.push(msg);
        }
        if(msg.sender_id == receiver_idInput){
            mergeArr.push(msg);
        }
            mergeArr.forEach(e=>{
                var message = e.message;
                var messageElement = document.createElement("p");
                if(e.sender_id == sender_idInput){
                    messageElement.className = 'pclass ' + 'senderpclass';
                }
                else if(e.sender_id == receiver_idInput){
                    messageElement.className = 'pclass ' + 'receiverpclass';
                }
                messageElement.innerHTML = message;
                $('#allFeedback').append(messageElement)
                var validDate = convertDate(e.start_time);
                var dateElement = document.createElement("p");
                dateElement.className = 'datepclass';
                dateElement.innerHTML = validDate;
                messageElement.append(dateElement);
            })
    }
    function convertDate(timestamp){
        var d = new Date(timestamp);
        var month1 = (d.getMonth()) + 1;
        var month = month1.toString().length === 1 ? "0" + month1 : month1;
        var minutes1 = d.getMinutes();
        var minutes = minutes1.toString().length === 1 ? "0" + minutes1 : minutes1;
        var hours1 = d.getHours();
        var hours = hours1.toString().length === 1 ? "0" + hours1 : hours1;
        var date1 = d.getDate();
        var date = date1.toString().length === 1 ? "0" + date1 : date1;
        var year1 = d.getFullYear();
        var year = year1.toString().length === 1 ? "0" + year1 : year1;
        var validDate = date + '/' + month + '/' + year + ' ' + hours + ':' + minutes + ' ' + (d.getHours() >= 12 ? "PM" : "AM")
        return validDate;
    }
</script>