@extends('Layouts.main')
@section('content')
<link rel="stylesheet" href="https://res.cloudinary.com/dxfq3iotg/raw/upload/v1569006288/BBBootstrap/choices.min.css?version=7.0.0">
<script src="https://res.cloudinary.com/dxfq3iotg/raw/upload/v1569006273/BBBootstrap/choices.min.js?version=7.0.0"></script>
<style type="text/css">
  .choices__list--dropdown {word-break: normal !important;}
  .choices__list--multiple .choices__item{
    background-color: #696cff !important;
    border: 1px solid #696cff !important;
  }
  #css-dropdown
  {
      position: absolute;
      top: 0;
      right: 0;
      left: 0;
      width: 300px;
      height: 42px;
      margin: 100px auto 0 auto;
  }
  .choices__inner {
    overflow: scroll;
    height: 28%;
    background-color: #fff;
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3e%3cpath fill='none' stroke='rgba%2867, 89, 113, 0.6%29' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M2 5l6 6 6-6'/%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: right 0.875rem center;
    background-size: 17px 12px;
    border-radius: 0.375rem;
  }
  .choices__list--multiple .choices__item{padding: 4px 5px;}
  .choices__input {background-color: #fff;}
  </style>
<div class="layout-page">
  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
      <div class="row">
        <div class="col-xxl">
          <div class="row mb-5 custom-right-row-8">
            <div class="col-md-6 col-lg-6">
              <h6 class="custom_schedule_h6">{{Auth::user()->user_type == 1 || Auth::user()->user_type == 3 ? 'Training Videos' : 'Practice Videos'}}</h6>
            </div>
            <div class="col-md-6 col-lg-6">
              <meta name="csrf-token" content="{{ csrf_token() }}" />
              <input type="hidden" name="user_id" id="user_id" value="{{$coach_id}}">
              <div class="row">
                <div class="col-sm-6">
                  <select name="media_tags[]" class="form-select selectpicker" id="choices-multiple-remove-button" multiple data-live-search="true" placeholder="Tags">
                    {{-- <option selected>Tags</option> --}}
                    @foreach ($mediaTags as $mediaTags)
                      <option value="{{$mediaTags->id}}">{{$mediaTags->name}}</option>
                    @endforeach
                  </select>
                </div>
                <div class="col-sm-6">
                  <input type="date" class="form-select" style="background-image:none;padding: 0.75rem 0.875rem 0.4375rem 0.875rem;" placeholder="date"/>
                  {{-- <select id="gender" name="gender" class="form-select" style="padding: 0.4375rem 1.875rem 0.8rem 0.875rem;">
                    <option>Date</option>
                    <option value="male">Yesterday</option>
                  </select> --}}
                </div>
              </div>
            </div>
          </div>
          @if(Auth::user()->user_type == 2)
          <div class="row mb-5" id="videoId">
          </div>
          @else
          <div id="videoId1"></div>
          @endif
        </div>
      </div>
    </div>
  </div>
</div>
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script>
  $(document).ready (function () { 
    $('#videoId').css('display','none');
    getVideo([]);
    var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
        removeItemButton: true,
        maxItemCount:100,
        searchResultLimit:10,
        renderChoiceLimit:10
    });
    $('#athlete_nameId').change(function () {
      var athletename = this.value;
      $("#videoId").empty();
      $.ajax({
          url: '/getAthletePracticeVideo/'+athletename,
          type: "GET",
          success: function (result) {
            console.log(result);
            $.each(result, function(index, obj){
                var div = $("<div class='col-md-6 col-lg-4' style='width: 30.333333%;'>");
                div.append("<div class='card mb-4'>");
                div.append("<div class='card-body' style='padding: 0'>");
                div.append("<video style='width: 277px;height: 156px;border-radius: 4px;' controls>")
                div.append("<source src='"+obj.video_url+"' alt='./assets/img/defaultVideo.mp4' type='video/mp4'>")
                div.append("</video>")
                div.append("</div>")
                div.append("</div>")
                div.append("</div>")
                $("#videoId").append(div);
            });
          }
      });
    })
    $("#choices-multiple-remove-button").change(function () {
      let selected_tag = $(this).val().length > 0 ? $(this).val() : [];
      getVideo(selected_tag);
    });
  });
  function getVideo(selected_tag){
    let user_id = $('#user_id').val();
    $.ajax({
        url: '/getFilterVideo/'+user_id,
        type: "POST",
        data: {selected_tag:selected_tag,user_id:user_id},
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function (result) {
          $('#videoId1').html(result);
        }
    });
  }
</script>