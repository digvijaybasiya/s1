@extends('Layouts.main')
@section('content')
<link rel="stylesheet" href="https://res.cloudinary.com/dxfq3iotg/raw/upload/v1569006288/BBBootstrap/choices.min.css?version=7.0.0">
<script src="https://res.cloudinary.com/dxfq3iotg/raw/upload/v1569006273/BBBootstrap/choices.min.js?version=7.0.0"></script>
<style type="text/css">
.choices__list--multiple .choices__item{
  background-color: #696cff !important;
  border: 1px solid #696cff !important;
}
#css-dropdown
{
    position: absolute;
    top: 0;
    right: 0;
    left: 0;
    width: 300px;
    height: 42px;
    margin: 100px auto 0 auto;
}
.dropdown-menu{min-width: 10rem;}
</style>
<div class="layout-page">
  <div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y">
      <div class="row">
        <div class="col-xxl">
          <div class="row mb-5 custom-right-row-8">
            <div class="col-md-6 col-lg-6">
              <h6 class="custom_schedule_h6">{{Auth::user()->user_type == 1 || Auth::user()->user_type == 3 ? 'Practice Videos' : 'Training Videos'}}</h6>
            </div>
            <div class="col-md-6 col-lg-6">
              <div class="row">
                @if(Auth::user()->user_type == 3)<div class="col-sm-6"></div>@endif
                <div class="col-sm-6">
                  <input type="date" class="form-select" style="background-image:none;padding: 0.6rem 0.8rem 0.5rem 0.6rem;" placeholder="date"/>
                  {{-- <select id="gender" name="gender" class="form-select">
                    <option>Date</option>
                    <option value="male">Yesterday</option>
                  </select> --}}
                </div>
                @if(Auth::user()->user_type != 3)
                <div class="col-sm-6">
                  <input type="button" class="btn btn-primary custom_upload_btn"
                  data-bs-toggle="modal"
                  data-bs-target="#uploadVideoModal"  value="Upload"/>
                </div>
                @endif
              </div>
            </div>
          </div>
          <div class="row mb-5">
            @foreach ($videoData as $videoData)
              <div class="col-md-6 col-lg-4" style="width: 30.333333%;">
                <div class="card mb-4">
                  <div class="card-body" style="padding: 0">
                    @if (Auth::user()->user_type == 1 || Auth::user()->user_type == 3)
                      <a href="{{url('openVideo/'.$videoData->id.'/')}}">
                      <video style="width: 277px;height: 156px;border-radius: 4px;" controls>
                        <source src="{{$videoData->video_url}}" alt="./assets/img/defaultVideo.mp4" type="video/mp4">
                      </video>
                      </a>
                    @else
                      <video style="width: 277px;height: 156px;border-radius: 4px;" controls>
                        <source src="{{$videoData->video_url}}" alt="./assets/img/defaultVideo.mp4" type="video/mp4">
                      </video>
                    @endif
                  </div>
                </div>
              </div>    
            @endforeach
          </div>
      </div>
    </div>

    <div class="content-backdrop fade"></div>
  </div>
</div>
@endsection
<!-- Modal -->
<div class="modal fade" id="uploadVideoModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
        <div class="modal-header">
          <h6 class="modal-title custom_schedule_h6" id="uploadVideo">Upload Video</h6>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="POST" id="addNewVideo" enctype="multipart/form-data">
            @csrf
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <div class="modal-body">
              <div class="row mb-3">
                <label class="col-sm-2 col-form-label" for="basic-default-name">Video Title</label>
                <div class="col-sm-10">
                  <input type="text" class="form-control" id="videoTitle" name="videoTitle" placeholder="Video Title" style="padding: 0.4375rem 0.5rem;" />
                </div>
              </div>
              <div class="mb-3 row">
                  <label for="html5-date-input" class="col-sm-2 col-form-label">Select Tags</label>
                  <div class="col-sm-10">
                    <select class="form-control selectpicker"  name="medianTaggs[]" id="choices-multiple-remove-button" multiple data-live-search="true" placeholder="Select Tags">
                      @foreach ($tags as $tag)
                          <option value="{{$tag->id}}">{{$tag->name}}</option>
                      @endforeach 
                    </select>
                    {{-- <select class="form-control"  name="selectedtags">
                      <option value="">-----Select----</option>
                      @foreach ($mediaTags as $mediaTags)
                        <option value="{{$mediaTags->id}}">{{$mediaTags->name}}</option>
                      @endforeach
                    </select> --}}
                  </div>
              </div>
              <div class="mb-3 row">
                  <label for="defaultSelect" class="col-sm-2 col-form-label">Choose file to upload</label>
                  <div class="col-sm-10">
                      <input type="file" class="form-control" id="file" name="file" />
                  </div>
              </div>
            </div>
            <div class="modal-footer">
                <input type="button" value="Upload" onclick="saveVideo()" class="btn btn-primary" id="saveVideoId"/>
            </div>
        </form>
    </div>
  </div>
</div>
<script src="../assets/vendor/libs/jquery/jquery.js"></script>
<script src="../assets/vendor/libs/popper/popper.js"></script>
{{-- <script src="../assets/vendor/js/bootstrap.js"></script> --}}
<script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="../assets/vendor/js/menu.js"></script>
<!-- <script src="../assets/js/main.js"></script> -->
<script async defer src="https://buttons.github.io/buttons.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script>
  $(document).ready(function()
{
    var multipleCancelButton = new Choices('#choices-multiple-remove-button', {
        removeItemButton: true,
        maxItemCount:100,
        searchResultLimit:10,
        renderChoiceLimit:10
    });
});
function saveVideo()
{
    var fd = new FormData(document.getElementById('addNewVideo'));
        $.ajax({    //create an ajax request to display.php
            type: 'POST',
            url: '/upload/video', 
            data: fd,
            contentType: false,
            processData: false,   
            cache: false, 
            headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
            success: function(response)
            {                  
              alert(response.message);
                console.log(response);
                console.log(response.message);
                $('#uploadVideoModal').modal('hide');
            },
            error:function(error){
                console.log("error",error)
            }
        })
}
</script>