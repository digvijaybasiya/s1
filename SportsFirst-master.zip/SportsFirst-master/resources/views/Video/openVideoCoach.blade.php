@extends('Layouts.SelectedAthlete.Athlete_main_video')
@section('content')
    @include('Video.openVideo')
@endsection