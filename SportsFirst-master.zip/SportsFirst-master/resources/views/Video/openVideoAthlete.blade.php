@extends('Layouts.main')
@section('content')
    @include('Video.openVideo')
@endsection