
@section('content')



<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Verify Your Email Address</div>

                <div class="card-body">
                    @if($response['success'])
                        <div class="alert alert-success" role="alert">
                            {{$response['success']}}
                        </div>
                        
                    @else

                        <div class="alert alert-error" role="alert">
                            {{$response['error']}}
                        </div>

                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

@push('scripts')

@if($response['success'])
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
    <script type="text/javascript">
        jQuery(function($) {
            'use strict';
            window.location.href="{{url('/AccountRegister')}}";
        });
    </script>
@endif

@endpush
@stack('scripts')