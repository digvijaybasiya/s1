@extends('Layouts.main')
@section('content')
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"/>
<link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">	
<style>
    .dataTables_filter {display: none;}
    .btn-success {
        color: #fff;
        background-color: #696cff !important;
        border-color: #696cff !important;
    }
    table.dataTable thead th, table.dataTable thead td {padding: 10px 10px;border-bottom: none;}
    table.dataTable thead .sorting_asc{background-image: none;}
    table.dataTable thead .sorting_asc:before, table.dataTable thead .sorting_desc:after {display: none;}
    table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after, table.dataTable thead .sorting_asc_disabled:after, table.dataTable thead .sorting_desc_disabled:after {display: none}
</style>
<div class="layout-page">
    <!-- Content wrapper -->
    <div class="content-wrapper">
        <!-- Content -->
        <div class="container-xxl flex-grow-1 container-p-y">
            <!-- Basic Layout & Basic with Icons -->
            <div class="row">
                <!-- Basic Layout -->
                <div class="col-xxl custom-right-row-8">
                    <div class="row" style="margin-bottom: 2%;">
                        <div class="col-md-6 col-lg-8">
                            <input type="text" id="searchbox" class="custom-searchbox" placeholder="Search">
                        </div>
                        <div class="col-md-6 col-lg-4">
                            <button
                            class="btn btn-primary custom-urgent"
                            data-bs-toggle="modal"
                            data-bs-target="#modalCenter" style="float:right;" id="btn_open_invite_modal">Invite Athlete</button>
                        </div>
                    </div>
                        <div class="table-responsive text-nowrap">
                            <table class="table table-striped yajra-datatable" style="border:1px solid #E5E5E5;">
                              <thead>
                                <tr class="custom-dt-tr">
                                  {{-- <th>No</th> --}}
                                  <th>Name</th>
                                  <th>Parent Name</th>
                                  <th>Action</th>
                                </tr>
                              </thead>
                              <tbody class="table-border-bottom-0">
                              </tbody>
                            </table>
                        </div>
                    {{-- </div> --}}
                </div>
            </div>
        </div>
    <!-- / Content -->
    <div class="content-backdrop fade"></div>
</div>
<div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h6 class="mb-0 custom_mb-0 custom_schedule_h6" id="modalCenterTitle">Invite Athlete</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="form_invite_atheletes" enctype="multipart/form-data">
            <div class="modal-body">
                <div class="row"><div class="col mb-12" id="invite_msg_div"></div></div>
                <div class="row">
                    <div class="col mb-12 custom-padding-invitation">
                        <label for="invite_email" class="form-label send-invitation-modal">Email Address</label>
                        <input type="text" id="to_do_task" name="invite_email" class="form-control" placeholder="Enter Email Address"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-12">
                        <label for="invite_msg" class="form-label send-invitation-modal">Message</label>
                        <textarea class="form-control" rows="4" name="invite_msg"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" value="Add Item" class="btn btn-primary addtodoitemBtn custom-urgent" id="btn_invite_athelete">Send Invitation</button>
            </div>
        </form>
    </div>
    </div>
</div>
@endsection
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
 
<script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" defer="defer"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script type="text/javascript">
$(function () {
    var dataTable = $('.yajra-datatable').dataTable();
	var table = $('.yajra-datatable').DataTable({
		destroy: true,
	    processing: true,
	    serverSide: true,
        bLengthChange: false,
        bInfo: false,
        bSort: false,
	    ajax: "{{ route('/myAthlete/fetch') }}",
	    columns: [
	        // {data: 'DT_RowIndex', name: 'DT_RowIndex'},
	        {data: 'username', name: 'username'},
            {data: 'parentname', name: 'parentname'},
	        {
	            data: 'action', 
	            name: 'action', 
	            orderable: true, 
	            searchable: true
	        },
	    ]
	});
    $("#searchbox").keyup(function() {
        dataTable.fnFilter(this.value);
    });  
});
function athleteView(id){
    window.location.replace('/athlete/'+id+'/dashboard');
}
</script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/additional-methods.min.js"></script>

<script type="text/javascript">
    jQuery(function($) {
        'use strict';

        $('body').on('click','#btn_open_invite_modal',function(){
            $('#modalCenter').modal('show');
        });

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#form_invite_atheletes').validate({
            rules:{
                invite_email:{
                    required:true,
                    email:true
                },
                invite_msg:{
                    required:true,
                    minlength:2,
                    maxlength:255
                }
            },
            messages:{
                invite_email:{
                    required:'Enter email address please',
                    email:'Not a valid email address'
                },
                invite_msg:{
                    required:'Enter some message'
                }
            },
            submitHandler:function(){
                var formData=new FormData($('#form_invite_atheletes')[0]);
                formData.append('_token','{{ csrf_token() }}');

                $.ajax({
                    type:'POST',
                    url:"{{url('/atheletes_invite')}}",
                    data:formData,
                    dataType:'json',
                    cache: false,
                    contentType: false,
                    processData: false,
                    beforeSend:function(){

                    },
                    success:function(d){
                        if(d.success){
                            $('#invite_msg_div').html('<span class="alert alert-success">'+d.success+'</div>');
                        }else{
                            $('#invite_msg_div').html('<span class="alert alert-error">'+d.error+'</span>');
                        } 
                        alert(d.success) ;
                        $('#modalCenter').modal('hide'); 
                        location.reload();                
                    },
                    complete:function(xhr,status){
                        setTimeout(function(){
                            $('#invite_msg_div').html('');
                        },3000);
                    }
                });
            }
        });

    });
</script>