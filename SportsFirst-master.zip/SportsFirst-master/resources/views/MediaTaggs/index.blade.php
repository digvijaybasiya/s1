@extends('Layouts.main')
	@section('content')
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"/>
    <link href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">	
    <meta name="csrf-token" content="{{ csrf_token() }}">
	<style>
		.dataTables_filter {display: none;}
		.btn-success {
			color: #fff;
			background-color: #696cff !important;
			border-color: #696cff !important;
		}
		.btn-primary {
			color: #fff;
			background-color: #696cff !important;
			border-color: #696cff !important;
		}
		table.dataTable thead th, table.dataTable thead td {padding: 10px 10px;border-bottom: none;}
		table.dataTable thead .sorting_asc{background-image: none;}
		table.dataTable thead .sorting_asc:before, table.dataTable thead .sorting_desc:after {display: none;}
		table.dataTable thead .sorting:after, table.dataTable thead .sorting_asc:after, table.dataTable thead .sorting_desc:after, table.dataTable thead .sorting_asc_disabled:after, table.dataTable thead .sorting_desc_disabled:after {display: none}
	</style>
	<!-- Layout wrapper -->
		<div class="layout-page">
			<!-- Content wrapper -->
			<div class="content-wrapper">
				<!-- Content -->
				<div class="container-xxl flex-grow-1 container-p-y">
					<!-- Basic Layout & Basic with Icons -->
					<div class="row">
						<!-- Basic Layout -->
						<div class="col-xxl custom-right-row-8">
							<div class="row" style="margin-bottom: 2%;">
								<div class="col-md-6 col-lg-8">
									<input type="text" id="searchbox" class="custom-searchbox" placeholder="Search">
								</div>
								<div class="col-md-6 col-lg-4">
									<button
									class="btn btn-primary custom-urgent"
									data-bs-toggle="modal"
									data-bs-target="#modalCenter" style="float: right;" id="btn_open_invite_modal">Add Media Tag</button>
								</div>
							</div>
								<div class="table-responsive text-nowrap">
									<table class="table table-striped yajra-datatable" style="border:1px solid #E5E5E5;" id="tagsList">
									  <thead>
										<tr class="custom-dt-tr">
										  {{-- <th>No</th> --}}
										  <th>Name</th>
										  <th>Action</th>
										</tr>
									  </thead>
									  <tbody class="table-border-bottom-0">
									  </tbody>
									</table>
								</div>
						</div>
					</div>
				</div>
			<!-- / Content -->
			<div class="content-backdrop fade"></div>
		</div>
		<!-- Content wrapper -->
	</div>
	<!-- / Layout wrapper -->
	<!-- Modal -->
	<div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
	    <div class="modal-dialog modal-dialog-centered" role="document">
	    <div class="modal-content">
	        <div class="modal-header">
	        <h5 class="modal-title" id="modalCenterTitle">Add New Tag</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	        </div>
	        <form method="POST" id="addtag" action="{{ route('addToDoItem') }}" enctype="multipart/form-data">
	            {{-- @csrf --}}
	            <meta name="csrf-token" content="{{ csrf_token() }}">
	            <div class="modal-body">
	                <div class="row">
	                    <div class="col mb-3">
	                    <label for="nameWithTitle" class="form-label">Tag</label>
	                    <input type="text" id="tag" name="tag" class="form-control" placeholder="Enter tag"/>
	                    </div>
	                </div>
	            </div>
	            <div class="modal-footer">
	                <input type="button" onclick="saveTag()" value="Save" class="btn btn-primary addtodoitemBtn" id="addtodoitemBtn"/>
	            </div>
	        </form>
	    </div>
	    </div>
	</div>

	<!-- EDIT MODEL -->
	<!-- Modal -->
	<div class="modal fade" id="updateModel" tabindex="-1" aria-hidden="true">
	    <div class="modal-dialog modal-dialog-centered" role="document">
	    <div class="modal-content">
	        <div class="modal-header">
	        <h5 class="modal-title" id="modalCenterTitle">Update Tag</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	        </div>
	        <form method="POST" id="edittag"  enctype="multipart/form-data">
	            {{-- @csrf --}}
	            <meta name="csrf-token" content="{{ csrf_token() }}">
	            <div class="modal-body">
	                <div class="row">
	                    <div class="col mb-3">
	                    <label for="nameWithTitle" class="form-label">Tag</label>
	                    <input type="text" id="etag" name="uptag" class="form-control" placeholder="Enter tag"/>
	                    <input type="hidden" id="eid" name="eid" class="form-control" placeholder="Enter tag"/>
	                    </div>
	                </div>
	            </div>
	            <div class="modal-footer">
	                <input type="button" onclick="updateTag()" value="Save" class="btn btn-primary addtodoitemBtn"/>
	            </div>
	        </form>
	    </div>
	    </div>
	</div>
	<!-- EDIT MODEL -->
	@endsection
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
 
<script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" defer="defer"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>

<script type="text/javascript">
$(function () {
	var dataTable = $('.yajra-datatable').dataTable();
	var table = $('.yajra-datatable').DataTable({
		destroy: true,
	    processing: true,
	    serverSide: true,
        bLengthChange: false,
        bInfo: false,
        bSort: false,
	    ajax: "{{ route('/media/taggs/fetch') }}",
	    columns: [
	        // {data: 'DT_RowIndex', name: 'DT_RowIndex'},
	        {data: 'name', name: 'name'},
	        {
	            data: 'action', 
	            name: 'action', 
	            orderable: true, 
	            searchable: true
	        },
	    ]
	});
    $("#searchbox").keyup(function() {
        dataTable.fnFilter(this.value);
    });  
});
// SAVE
function saveTag()
{
	var formData = new FormData(document.getElementById('addtag'));
	$.ajax({   
			type: 'POST',
			url: '/media/taggs/save', 
			data: formData,
			contentType: false,
			processData: false,   
			cache: false, 
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			success: function(response)
			{
				$('#addtag')[0].reset();                    
				$('#modalCenter').modal('toggle');
				$("#tagsList").DataTable().ajax.reload();
				var res =JSON.parse(response); 
                if(res.status==1)
                {
                    $.notify(res.message,"success");
                }
                else
                {
                    $.notify(res.message,"error");
                }
				//console.log(response);return false;
			},
			error:function(error)
			{
				console.log("error",error)
			}
		})
}
// SAVE
//READ//
function edit(id)
{
	$.ajax({
			url: '/media/taggs/read',    
			type: 'POST',
			data: { id: id },
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			success: function(response)
			{
				$("#etag").val(response.message.name);
				$("#eid").val(response.message.id);
				$('#updateModel').modal('toggle');
				//console.log(response.message.name);return false;
			},
			error:function(error)
			{
				console.log("error",error)
			}
		})
}
//READ//
//UPDATE//
function updateTag()
{
	var formData = new FormData(document.getElementById('edittag'));
	$.ajax({   
			type: 'POST',
			url: '/media/taggs/update', 
			data: formData,
			contentType: false,
			processData: false,   
			cache: false, 
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			success: function(response)
			{
				//console.log(response);return false;
				$('#edittag')[0].reset();                    
				$('#updateModel').modal('toggle');
				$("#tagsList").DataTable().ajax.reload();
				var res =JSON.parse(response); 
                if(res.status==1)
                {
                    $.notify(res.message,"success");
                }
                else
                {
                    $.notify(res.message,"error");
                } 
			},
			error:function(error)
			{
				console.log("error",error)
			}
		})
}
//UPDATE//
//DELETE//
function deleterecord(id)
{
	$.ajax({
			url: '/media/taggs/delete',    
			type: 'POST',
			data: { id: id },
			headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
			success: function(response)
			{
				$("#tagsList").DataTable().ajax.reload();
				var res =JSON.parse(response); 
                if(res.status==1)
                {
                    $.notify(res.message,"success");
                }
                else
                {
                    $.notify(res.message,"error");
                } 	
			},
			error:function(error)
			{
				console.log("error",error)
			}
		})
}
//DELETE//
</script>