
@extends('Layouts.main')
@section('content')
    <!-- Layout wrapper -->
        <div class="layout-page">

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              {{-- <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Horizontal Layouts</h4> --}}

              <!-- Basic Layout & Basic with Icons -->
              <div class="row">
                <!-- Basic Layout -->
                <div class="col-xxl">
                  <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h6 class="mb-0 custom_mb-0 custom_schedule_h6">Your Profile Details</h6>
                    </div>
                    <div class="card-body">
                        <h5 class="mb-0">Personal Information</h5>
                      <form class="custom_form-padding" action="{{ route('addProfile') }}" id="profileForm" method="POST" enctype="multipart/form-data">
                        @csrf
                        {{-- <meta name="csrf-token" content="{{ csrf_token() }}"> --}}
                        {{-- @csrf --}}
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-name">First Name</label>
                          <div class="col-sm-10">
                            <input type="hidden" class="form-control" id="user_id" name="user_id" placeholder="1" value={{ $userData ? $userData->id : ''}} >
                            <input type="text" class="form-control" id="first_name" name="first_name" placeholder="Enter first name" value={{ $userData ? $userData->name : ''}}>
                          </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-name">Last Name</label>
                            <div class="col-sm-10">
                              <input type="text" class="form-control" id="last_name" name="last_name" placeholder="John Doe" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="html5-date-input" class="col-sm-2 col-form-label">DOB</label>
                            <div class="col-sm-10">
                              <input class="form-control" type="date" name="DOB" value="2021-06-18" id="DOB" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">Gender</label>
                            <div class="col-sm-10">
                                <select id="gender" name="gender" class="form-select">
                                <option>Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">Blood Group</label>
                            <div class="col-sm-10">
                                <select id="blood_group" name="blood_group" class="form-select">
                                <option>Blood group</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">State</label>
                            <div class="col-sm-10">
                                <select id="state-dropdown" name="state" class="form-select">
                                  @foreach ($state as $state)
                                    <option value="{{$state->id}}">{{$state->name}}</option>
                                  @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">City</label>
                            <div class="col-sm-10">
                                <select id="city" name="city" class="form-select">
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-company">Weight</label>
                          <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <input
                                  type="text"
                                  id="weight"
                                  name="weight"
                                  class="form-control"
                                  placeholder="100"
                                  aria-label="100"
                                  aria-describedby="weight"
                                />
                                <span class="input-group-text" id="basic-default-email2">kgs</span>
                            </div>
                          </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-name">Pincode</label>
                            <div class="col-sm-10">
                              <input type="text" class="form-control" id="pincode" name="pincode" placeholder="348097" />
                            </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-message">Address</label>
                          <div class="col-sm-10">
                            <textarea
                              id="address"
                              class="form-control"
                              placeholder="address"
                              aria-label="address"
                              aria-describedby="address"
                              name="address"
                            ></textarea>
                          </div>
                        </div>
                        <h5 class="mb-0">Training information</h5>
                        <div class="custom_form-padding">
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Sports</label>
                                <div class="col-sm-10">
                                    <select id="sports_name" name="sports_name" class="form-select">
                                    <option>Sports</option>
                                    <option value="Cricket">Cricket</option>
                                    <option value="Badminton">Badminton</option>
                                    <option value="TT">TT</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Playstyle/Position</label>
                                <div class="col-sm-10">
                                    <select id="position" name="position" class="form-select">
                                    <option>RHB</option>
                                    <option value="RHB">RHB</option>
                                    <option value="RHB2">RHB</option>
                                    </select>
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Training Days</label>
                                <div class="col-sm-10">
                                    <select id="training_days" name="training_days" class="form-select">
                                    <option>Days</option>
                                    <option value="Monday">Monday</option>
                                    <option value="Tuesday">Tuesday</option>
                                    <option value="Wednesday">Wednesday</option>
                                    <option value="Thursday">Thursday</option>
                                    <option value="Friday">Friday</option>
                                    <option value="Saturday">Saturday</option>
                                    <option value="Sunday">Sunday</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row justify-content-end">
                          <div class="col-sm-10">
                            <input type="button" class="btn btn-primary" id="Add" onclick="saveProfile()" value="Submit"/>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
    <!-- / Layout wrapper -->
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script>
  function saveProfile(){
    var fd = new FormData(document.getElementById('profileForm'));
        // var url = '{{ url('/addProfile') }}';
    $.ajax({    //create an ajax request to display.php
        type: 'POST',
        url: '/addProfile',
        data: fd,
        contentType: false,
        processData: false,
        cache: false,
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function(response)
        {        
        console.log(response);
        alert(response.message)
        },
        error:function(error){
            console.log("error",error)
        }
    })
  }
    $(document).ready (function () { 
      $('#state-dropdown').change(function () {
        var idState = this.value;
        $("#city").html('');
        $.ajax({
            url: '/getCities/'+idState,
            type: "GET",
            success: function (result) {
              console.log("dsdf",result)
              if(result.length != 0){
                $('#city').html('<option value="">-- Select City --</option>');
                $.each(result, function (key, value) {
                  console.log("dsdf",value)
                    $("#city").append('<option value="' + value
                        .id + '">' + value.name + '</option>');
                });
              }
            }
        });
      })
    });
</script>
