
@extends('Layouts.main')
@section('content')
    <!-- Layout wrapper -->
        <div class="layout-page">

          <!-- Content wrapper -->
          <div class="content-wrapper">
            <!-- Content -->

            <div class="container-xxl flex-grow-1 container-p-y">
              {{-- <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Horizontal Layouts</h4> --}}

              <!-- Basic Layout & Basic with Icons -->
              <div class="row">
                <!-- Basic Layout -->
                <div class="col-xxl">
                  <div class="card mb-4">
                    <div class="card-header d-flex align-items-center justify-content-between">
                      <h6 class="mb-0 custom_mb-0 custom_schedule_h6">Athlete details</h6>
                      <div class="mb-3 row">
                          <label for="defaultSelect" class="col-sm-8 col-form-label">Athlete name</label>
                          <div class="col-sm-10">
                              <select id="athlete_name" name="athlete_name" class="form-select">
                                <option>Select Name</option>
                              @foreach ($athleteName as $athleteName)
                                <option value="{{$athleteName->id}}">{{$athleteName->name}}</option>
                              @endforeach
                              </select>
                          </div>
                      </div>
                    </div>
                    <div class="card-body">
                        <h5 class="mb-0" id='mb0' style="display: none;">Personal information</h5>
                    <form id="f1" class="custom_form-padding" style="display: none;">
                        {{-- <meta name="csrf-token" content="{{ csrf_token() }}"> --}}
                        {{-- @csrf --}}
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-name">First Name</label>
                          <div class="col-sm-10">
                            <input type="text" readonly class="form-control" id="first_name" name="first_name" />
                          </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-name">Last Name</label>
                            <div class="col-sm-10">
                              <input type="text" readonly class="form-control" id="last_name" name="last_name" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="html5-date-input" class="col-sm-2 col-form-label">DOB</label>
                            <div class="col-sm-10">
                              <input class="form-control" readonly type="date" name="DOB" id="DOB" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">Gender</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="gender" name="gender" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">Blood Group</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="blood_group" name="blood_group" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">State</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="state_name" name="state_name" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">City</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="city_name" name="city_name" />
                            </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-company">Weight</label>
                          <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <input
                                  type="text"
                                  readonly
                                  id="weight"
                                  name="weight"
                                  class="form-control"
                                  aria-label="100"
                                  aria-describedby="weight"
                                />
                                <span class="input-group-text" id="basic-default-email2">kgs</span>
                            </div>
                          </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-name">Pincode</label>
                            <div class="col-sm-10">
                              <input type="text" readonly class="form-control" id="pincode" name="pincode" />
                            </div>
                        </div>
                        <div class="row mb-3">
                          <label class="col-sm-2 col-form-label" for="basic-default-message">Address</label>
                          <div class="col-sm-10">
                            <textarea
                            readonly
                              id="address"
                              class="form-control"
                              aria-label="address"
                              aria-describedby="address"
                              name="address"
                            ></textarea>
                          </div>
                        </div>
                        <h5 class="mb-0">Training information</h5>
                        <div class="custom_form-padding">
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Sports</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly class="form-control" id="sports_name" name="sports_name" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Playstyle/Position</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly class="form-control" id="position" name="position" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Training Days</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly class="form-control" id="training_days" name="training_days" />
                                </div>
                            </div>
                        </div>
                    </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- / Content -->

            <div class="content-backdrop fade"></div>
          </div>
          <!-- Content wrapper -->
        </div>
    <!-- / Layout wrapper -->
@endsection
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script>
    $(document).ready (function () { 
      $.ajax({    //create an ajax request to display.php
        type: 'GET',
        url: '/getAuthUser',
        contentType: false,
        processData: false,
        cache: false,
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function(response)
        {        
        // console.log(response);
        if(response.user_type == 1){
          $('input').prop('readonly',true);
          $('select').attr("disabled", true); 
          $('textarea').prop('readonly',true);
        }
        console.log(response.id);
        // alert(response.message)
        },
        error:function(error){
            console.log("error",error)
        }
      })
      $('#athlete_name').change(function () {
        var athletename = this.value;
        $.ajax({
            url: '/getAthleteData/'+athletename,
            type: "GET",
            success: function (result) {
              $("#f1").css("display", "block");
              $("#mb0").css("display", "block");
              $('#first_name').val(result.name)
              $('#last_name').val(result.last_name)
              $('#DOB').val(result.DOB)
              $('#gender').val(result.gender)
              $('#blood_group').val(result.blood_group)
              $('#state_name').val(result.state_name)
              $('#city_name').val(result.city_name)
              $('#weight').val(result.weight)
              $('#pincode').val(result.pincode)
              $('#address').val(result.address)
              $('#sports_name').val(result.sports_name)
              $('#position').val(result.position)
              $('#training_days').val(result.training_days)
            }
        });
      })
    });
</script>