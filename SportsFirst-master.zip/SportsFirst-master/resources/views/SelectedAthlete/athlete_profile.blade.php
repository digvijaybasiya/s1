@extends('Layouts.SelectedAthlete.Athlete_Main')
@section('content')
<!-- Layout wrapper -->
<div class="layout-page">

    <!-- Content wrapper -->
    <div class="content-wrapper">
    <!-- Content -->

    <div class="container-xxl flex-grow-1 container-p-y custom-select-displayvideo" style="padding-top: 0px !important;">
        {{-- <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Forms/</span> Horizontal Layouts</h4> --}}

        <!-- Basic Layout & Basic with Icons -->
        <div class="row">
        <!-- Basic Layout -->
        <div class="col-xxl">
                <div class="card-header d-flex align-items-center justify-content-between">
                  <h6 class="mb-0 custom_mb-0 custom_schedule_h6">Athlete details</h6>
                </div>
                <div class="card-body">
                    <h5 class="mb-0" id='mb0'>Personal information</h5>
                    <form id="f1" class="custom_form-padding">
                        {{-- <meta name="csrf-token" content="{{ csrf_token() }}"> --}}
                        {{-- @csrf --}}
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-name">First Name</label>
                            <div class="col-sm-10">
                            <input type="text" readonly class="form-control" id="first_name" name="first_name" value="{{$athleteData->name}}"/>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-name">Last Name</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="last_name" name="last_name" value="{{$athleteData->last_name}}"/>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="html5-date-input" class="col-sm-2 col-form-label">DOB</label>
                            <div class="col-sm-10">
                                <input class="form-control" readonly type="date" name="DOB" id="DOB" value="{{$athleteData->DOB}}"/>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">Gender</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="gender" name="gender" value="{{$athleteData->gender}}"/>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">Blood Group</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="blood_group" name="blood_group" value="{{$athleteData->blood_group}}"/>
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">State</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="state_name" name="state_name" value="{{$athleteData->state_name}}" />
                            </div>
                        </div>
                        <div class="mb-3 row">
                            <label for="defaultSelect" class="col-sm-2 col-form-label">City</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="city_name" name="city_name" value="{{$athleteData->city_name}}" />
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-company">Weight</label>
                            <div class="col-sm-10">
                            <div class="input-group input-group-merge">
                                <input
                                    type="text"
                                    readonly
                                    id="weight"
                                    name="weight"
                                    class="form-control"
                                    aria-label="100"
                                    aria-describedby="weight"
                                value="{{$athleteData->weight}}" />
                                <span class="input-group-text" id="basic-default-email2">kgs</span>
                            </div>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-name">Pincode</label>
                            <div class="col-sm-10">
                                <input type="text" readonly class="form-control" id="pincode" name="pincode" value="{{$athleteData->pincode}}" />
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-2 col-form-label" for="basic-default-message">Address</label>
                            <div class="col-sm-10">
                            <textarea
                            readonly
                                id="address"
                                class="form-control"
                                aria-label="address"
                                aria-describedby="address"
                                name="address">{{$athleteData->address}}</textarea>
                            </div>
                        </div>
                        <h5 class="mb-0">Training information</h5>
                        <div class="custom_form-padding">
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Sports</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly class="form-control" id="sports_name" name="sports_name" value="{{$athleteData->sports_name}}" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Playstyle/Position</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly class="form-control" id="position" name="position" value="{{$athleteData->position}}" />
                                </div>
                            </div>
                            <div class="mb-3 row">
                                <label for="defaultSelect" class="col-sm-2 col-form-label">Training Days</label>
                                <div class="col-sm-10">
                                    <input type="text" readonly class="form-control" id="training_days" name="training_days" value="{{$athleteData->training_days}}" />
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        </div>
    </div>
    <!-- / Content -->

    <div class="content-backdrop fade"></div>
    </div>
    <!-- Content wrapper -->
</div>
@endsection