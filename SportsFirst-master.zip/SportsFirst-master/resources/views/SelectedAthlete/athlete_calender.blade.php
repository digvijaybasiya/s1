@extends('Layouts.SelectedAthlete.Athlete_Main')
@section('content')
    @include('Calendar.index')
@endsection