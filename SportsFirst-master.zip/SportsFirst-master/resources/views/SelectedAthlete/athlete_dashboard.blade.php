@extends('Layouts.SelectedAthlete.Athlete_Main')
@section('content')
    @include('Score.index')
@endsection