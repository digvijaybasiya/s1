@extends('Layouts.main')
@section('content')
    @include('Score.index')
@endsection