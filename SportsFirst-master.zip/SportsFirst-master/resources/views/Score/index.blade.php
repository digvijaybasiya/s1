
<div class="layout-page">
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-lg-12 order-0">
                    <div class="row mb-5 {{(request()->id == '') ? 'custom-right-row-8' : ''}}">
                        <div class="col-md-6 col-lg-3 custom-width">
                            <div class="card mb-3 custom_card_mb-3">
                            <div class="card-body">
                                <h6 class="card-title custom_h6">Total Run</h6>
                                <p class="card-text custom_h6">219</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3 custom-width">
                            <div class="card mb-3 custom_card_mb-3">
                            <div class="card-body">
                                <h6 class="card-title custom_h6">Average strike rate</h6>
                                <p class="card-text custom_h6">219</p>
                            </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-3 custom-width">
                            <div class="card mb-3 custom_card_mb-3">
                            <div class="card-body">
                                <h6 class="card-title custom_h6">Best Score</h6>
                                <p class="card-text custom_h6">219</p>
                            </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-lg-12 order-2 order-md-3 order-lg-2 mb-4">
                            <div class="row">
                                <div class="col-md-6 col-lg-6">
                                  <h6 class="custom_schedule_h6 custom_h6">{{Auth::user()->user_type == 1 ? 'Progress Board' : 'Athlete Score Board'}}</h6>
                                </div>
                                @if (request()->id != '')
                                    <div class="col-md-6 col-lg-6">
                                        <button class="btn btn-primary" style="float:right" 
                                        data-bs-toggle="modal"
                                        data-bs-target="#addScore">Add</button>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="row mb-5">
                        <div class="col-md-6 col-lg-12">
                            @if (count($progressData)>0)
                            <div class="card">
                                <div class="table-responsive text-nowrap">
                                <table class="table table-striped" id="scoreList">
                                    <thead>
                                    <tr style="height: 40px;background: #e6e9ff;">
                                        <th>Date</th>
                                        <th>Matches</th>
                                        <th>Total Wicket</th>
                                        <th>Economy</th>
                                        <th>Percentage</th>
                                        <th>Best Average</th>
                                    </tr>
                                    </thead>
                                    <tbody class="table-border-bottom-0">
                                        @foreach ($progressData as $progressData)
                                            <tr>
                                                <td>{{$progressData->score_date}}</td>
                                                <td>{{$progressData->match_no}}</td>
                                                <td>{{$progressData->run}}</td>
                                                <td>{{$progressData->economy}}</td>
                                                <td>{{$progressData->percentage}}</td>
                                                <td>{{$progressData->best_avg}}</td>
                                            </tr>                                            
                                        @endforeach
                                    </tbody>
                                </table>
                                </div>
                            </div>
                            @else
                            <h6>No records yet</h6>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
          </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addScore" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Add score</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="POST" id="addScoreForm" action="{{ route('addToDoItem') }}" enctype="multipart/form-data">
            {{-- @csrf --}}
            <meta name="csrf-token" content="{{ csrf_token() }}">
            <div class="modal-body">
                <div class="row">
                    <div class="col mb-3">
                        <input type="date" id="score_date" name="score_date" class="form-control" placeholder="Select Date"/>
                        <input type="hidden" name="user_id" id="user_id" value="{{request()->id}}">
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <input type="text" id="match_no" name="match_no" class="form-control" placeholder="No of matches"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <input type="text" id="run" name="run" class="form-control" placeholder="Total Run"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <input type="text" id="economy" name="economy" class="form-control" placeholder="Average strike rate"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <input type="text" id="percentage" name="percentage" class="form-control" placeholder="Average SR Vs. Spin"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-3">
                        <input type="text" id="best_avg" name="best_avg" class="form-control" placeholder="Best Averages"/>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="button" onclick="saveTag()" value="Add" class="btn btn-primary addtodoitemBtn" id="addtodoitemBtn"/>
            </div>
        </form>
    </div>
    </div>
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
 
<script src="https://cdn.datatables.net/1.10.8/js/jquery.dataTables.min.js" defer="defer"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script>  
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script>
function saveTag()
{
    var formData = new FormData(document.getElementById('addScoreForm'));
    $.ajax({   
        type: 'POST',
        url: '/progressCard/save', 
        data: formData,
        contentType: false,
        processData: false,   
        cache: false, 
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function(response)
        {
            $('#addScoreForm')[0].reset();                    
            $('#addScore').modal('toggle');
            location.reload();
            $("#scoreList").DataTable().ajax.reload();
            // var res =JSON.parse(response); 
            // if(res.status==1)
            // {
            //     $.notify(res.message,"success");
            // }
            // else
            // {
            //     $.notify(res.message,"error");
            // }
            //console.log(response);return false;
        },
        error:function(error)
        {
            console.log("error",error)
        }
    })
}
</script>