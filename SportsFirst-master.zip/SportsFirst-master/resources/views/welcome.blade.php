{{-- @include('Auth.register') --}}
@include('Layouts.main')