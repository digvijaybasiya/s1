<nav class="navbar custom-athlete-navbar navbar-example navbar-expand-lg" style="z-index: 1081;">
    <div class="container-fluid">

        <div class="collapse navbar-collapse" id="navbar-ex-3">
        <div class="navbar-nav me-auto">
        </div>

        <form onsubmit="return false">
            <button class="btn btn-primary custom-urgent" data-bs-toggle="modal" style="background-color:#e1e1e1f2 !important;color: #4F5DC0;" data-bs-target="#modalCenter" id="btn_open_invite_modal">Invite Parent</button>
            <a class="btn custom-athlete-navbar-closeBtn" href="{{ route('myAthlete') }}" type="button"><i class='bx bx-x'></i></a>
        </form>
        </div>
    </div>
</nav>
<div class="modal fade" id="modalCenter" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h6 class="mb-0 custom_mb-0 custom_schedule_h6" id="modalCenterTitle">Invite Parent</h6>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form id="form_invite_atheletes" enctype="multipart/form-data">
            <div class="modal-body">
                <div class="row"><div class="col mb-12" id="invite_msg_div"></div></div>
                <div class="row">
                    <div class="col mb-12 custom-padding-invitation">
                        <input type="hidden" name="athlete_id" id="athlete_id" value="{{request()->id}}">
                        <label for="invite_email" class="form-label send-invitation-modal">Email Address</label>
                        <input type="text" id="to_do_task" name="invite_email" class="form-control" placeholder="Enter Email Address"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col mb-12">
                        <label for="invite_msg" class="form-label send-invitation-modal">Message</label>
                        <textarea class="form-control" rows="4" name="invite_msg"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" value="Add Item" class="btn btn-primary addtodoitemBtn custom-urgent" id="btn_invite_athelete">Send Invitation</button>
            </div>
        </form>
    </div>
    </div>
</div>
<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.js"></script>
<script>
    $('#form_invite_atheletes').validate({
            rules:{
                invite_email:{
                    required:true,
                    email:true
                },
                invite_msg:{
                    required:true,
                    minlength:2,
                    maxlength:255
                }
            },
            messages:{
                invite_email:{
                    required:'Enter email address please',
                    email:'Not a valid email address'
                },
                invite_msg:{
                    required:'Enter some message'
                }
            },
            submitHandler:function(){
                var formData=new FormData($('#form_invite_atheletes')[0]);
                formData.append('_token','{{ csrf_token() }}');

                $.ajax({
                    type:'POST',
                    url:"{{url('/parent_invite')}}",
                    data:formData,
                    dataType:'json',
                    cache: false,
                    contentType: false,
                    processData: false,
                    beforeSend:function(){

                    },
                    success:function(d){
                        if(d.success){
                            $('#invite_msg_div').html('<span class="alert alert-success">'+d.success+'</div>');
                        }else{
                            $('#invite_msg_div').html('<span class="alert alert-error">'+d.error+'</span>');
                        } 
                        alert(d.success) ;
                        $('#modalCenter').modal('hide');                 
                    },
                    complete:function(xhr,status){
                        setTimeout(function(){
                            $('#invite_msg_div').html('');
                        },3000);
                    }
                });
            }
        });
</script>