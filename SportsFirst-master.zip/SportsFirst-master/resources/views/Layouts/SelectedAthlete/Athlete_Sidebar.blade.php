{{-- @section('sidebarsec') --}}
<!-- Menu -->

<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">
    <div class="app-brand demo">
      {{-- <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
        <i class="bx bx-chevron-left bx-sm align-middle"></i>
      </a> --}}
    </div>
  
    <div class="menu-inner-shadow"></div>
  
    <ul class="menu-inner py-1">
        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
          <i class="bx bx-chevron-left bx-sm align-middle"></i>
        </a>
      <!-- Dashboard -->
      <li class="menu-item {{ (Route::currentRouteNamed('athlete/dashboard'))=='1' ? 'active' : '' }}">
        <a href="{{ url('athlete/'.request()->id.'/dashboard')}} " class="menu-link">
          <iconify-icon icon="cil:notes" class="menu-icon"></iconify-icon>
          {{-- <i class="menu-icon tf-icons bx bx-home-circle"></i> --}}
          <div data-i18n="Analytics">Overview</div>
        </a>
      </li>
      <li class="menu-item {{ (Route::currentRouteNamed('athlete/profile'))=='1' ? 'active' : '' }}">
        <a href="{{ url('athlete/'.request()->id.'/profile') }}" class="menu-link">
          <iconify-icon icon="carbon:user-profile" class="menu-icon"></iconify-icon>
          {{-- <i class='bx bxs-user menu-icon'></i> --}}
          <div data-i18n="Layouts">Profile</div>
        </a>
      </li>
      <li class="menu-item {{ (Route::currentRouteNamed('athlete/calendar'))=='1' ? 'active' : '' }}">
        <a href="{{ url('athlete/'.request()->id.'/calendar') }}" class="menu-link">
          <iconify-icon icon="simple-line-icons:calender" class="menu-icon"></iconify-icon>
          {{-- <i class='bx bxs-calendar menu-icon'></i> --}}
          <div data-i18n="Analytics">Calendar</div>
        </a>
      </li>
      <li class="menu-item {{ (Route::currentRouteNamed('athlete/displayVideo'))=='1' ? 'active' : '' }}">
        <a href="{{ url('athlete/'.request()->id.'/displayVideo') }}" class="menu-link">
          <iconify-icon icon="octicon:video-24" class="menu-icon"></iconify-icon>
          {{-- <i class='bx bx-video menu-icon'></i> --}}
          <div data-i18n="Analytics">Practice videos and Feedback</div>
        </a>
      </li>
    </ul>
  </aside>
  <!-- / Menu -->
  {{-- @endsection --}}