<!-- Navbar -->

<nav class="navbar navbar-expand-lg navbar-light mb-5 custom-nav-bg custom-navbar">
  <div class="container-fluid">
    <a class="navbar-brand1 custom-nav-a" href="javascript:void(0)">Welcome to SF Coach!</a>
    <button
      class="navbar-toggler"
      type="button"
      data-bs-toggle="collapse"
      data-bs-target="#navbarSupportedContent"
      aria-controls="navbarSupportedContent"
      aria-expanded="false"
      aria-label="Toggle navigation"
    >
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <div class="navbar-nav me-auto mb-2 mb-lg-0">
      </div>
      @if(Auth::user()->user_type == 3)
      <div class="nav-item dropdown">
        <select id="childList" class="nav-link dropdown-toggle custom-parent-child-dropdown" style="display: none;"></select>
      </div>
      @endif
      <b id="childName"></b>
      <div class="nav-item dropdown">
        <a style="color: #ffffff !important;" class="nav-link dropdown-toggle"
        href="javascript:void(0)"
        id="navbarDropdown"
        role="button"
        data-bs-toggle="dropdown"
        aria-expanded="false"><i style="font-size: 2.15rem;" class='bx bx-user-circle'></i>
          <b>{{ucfirst(Auth::user()->name)}}</b>
        </a>
        <ul class="dropdown-menu" aria-labelledby="navbarDropdown" style="margin: 0.5rem -5.25rem !important;">
          <li><a class="dropdown-item custom-dropdown-clr" href="{{route('profile')}}">Profile</a></li>
          <li>
            {{-- <a class="dropdown-item" href="javascript:void(0)">Logout</a> --}}
            <a href="{{ route('logout') }}" class="dropdown-item custom-dropdown-clr"
              onclick="event.preventDefault();
              document.getElementById('logout-form').submit();">
                <div data-i18n="Analytics">Logout</div>
              </a>
              <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                @csrf
            </form>
          </li>
        </ul>
      </div>
      {{-- <form class="d-flex" onsubmit="return false">
        <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search" />
        <button class="btn btn-outline-primary" type="submit">Search</button>
      </form> --}}
    </div>
  </div>
</nav>

<!-- / Navbar -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script>
$(document).ready(function () {
  getParentChild()
})
function getParentChild(){
  $.ajax({    //create an ajax request to get list of all athlete of the parent
      type: 'GET',
      url: '/getChildAthlete',
      headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
      success: function(response)
      {      
        if(response.length > 1){
          $('#childList').css('display','block');
          response.forEach((e)=>{
            let name = (e.name).charAt(0).toUpperCase() + (e.name).slice(1); //make first letter uppercase
            $("#childList").append(new Option(name, e.id));
          })
        }else if(response.length == 1){
          $('#childName').text("Child Name: "+response[0].name.charAt(0).toUpperCase() + (response[0].name).slice(1))
          $('#childList').css('display','none');
        }else{}
      },
      error:function(error){
          console.log("error",error)
      }
  })
}
</script>