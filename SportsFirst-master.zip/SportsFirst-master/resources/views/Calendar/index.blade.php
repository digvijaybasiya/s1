
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create Fullcalender CRUD Events in Laravel</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />
    <div class="layout-page">
        <div class="content-wrapper">
            <div class="container-xxl flex-grow-1 container-p-y">
              <div class="row">
                <div class="col-xxl {{request()->id == '' ? 'custom-right-row-8' : ''}}">
                    <div class="row mb-5">
                      <div class="col-md-6 col-lg-12">
                        <div id='full_calendar_events'></div>
                        <input type="hidden" id="athlete_id" value="{{request()->id}}">
                      </div>
                    </div>
                </div>
              </div>
            </div>
        </div>
    </div>
<!-- Modal -->
<div class="modal fade" id="calendarModal" tabindex="-1" aria-hidden="true">
    
    </div>
</div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.2/fullcalendar.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        $(document).ready(function () {

            setEventsToDates();

            var SITEURL = "{{ url('/') }}";
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                } 

            });
            let athlete_id = $('#athlete_id').val()
            let url = athlete_id == '' ? "/calendar" : "/athlete/"+ athlete_id +"/calendar"
            var event_start;
            var event_end;
            var calendar = $('#full_calendar_events').fullCalendar({
                editable: true,
                events: SITEURL + url,
                displayEventTime: true,
                eventRender: function (event, element, view) {
                  console.log(event);
                    if (event.allDay === 'true') {
                        event.allDay = true;
                    } else {
                        event.allDay = false;
                    }
                },
                headerToolbar: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'dayGridMonth,timeGridWeek,listWeek'
                },
                selectable: true,
                selectHelper: true,
                displayEventTime: false,
                select: function (event_start, event_end, allDay) {
                    event_start = $.fullCalendar.formatDate(event_start, "Y-MM-DD HH:mm:ss");
                    event_end = $.fullCalendar.formatDate(event_end, "Y-MM-DD HH:mm:ss");
                        $.ajax({
                            url: SITEURL + "/getScheduleModal/"+athlete_id,
                            data: {
                                event_start: event_start,
                                event_start: event_start,
                                type: 'create'
                            },
                            type: "POST",
                            success: function (data) {
                                $('#calendarModal').html(data)
                                $('#calendarModal').modal('show');
                            }
                        });
                    // }
                },
                // eventDrop: function (event, delta) {
                //     var event_start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");
                //     var event_end = $.fullCalendar.formatDate(event.end, "Y-MM-DD");
                //     $.ajax({
                //         url: SITEURL + '/calendar-crud-ajax',
                //         data: {
                //             title: event.event_name,
                //             start: event_start,
                //             end: event_end,
                //             id: event.id,
                //             type: 'edit'
                //         },
                //         type: "POST",
                //         success: function (response) {
                //             displayMessage("Event updated");
                //         }
                //     });
                // },
                // eventClick: function (event) {
                //     var eventDelete = confirm("Are you sure?");
                //     if (eventDelete) {
                //         $.ajax({
                //             type: "POST",
                //             url: SITEURL + '/calendar-crud-ajax',
                //             data: {
                //                 id: event.id,
                //                 type: 'delete'
                //             },
                //             success: function (response) {
                //                 calendar.fullCalendar('removeEvents', event.id);
                //                 displayMessage("Event removed");
                //             }
                //         });
                //     }
                // }
            });
        });
        function displayMessage(message) {
            toastr.success(message, 'Event');            
        }

        function setEventsToDates()
        {
          console.log("demo test"); 
        }
    </script>