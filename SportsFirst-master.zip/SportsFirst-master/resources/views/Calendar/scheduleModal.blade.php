<div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">Schedule</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <form method="POST" id="addScheduleForm" enctype="multipart/form-data">
            @csrf
            {{-- <meta name="csrf-token" content="{{ csrf_token() }}"> --}}
            <div class="modal-body">
                <div class="row">
                    <div class="col mb-3">
                        <select id="event_name" name="event_name" class="form-select @error('event_name') is-invalid @enderror" placeholder="Select Sports">
                            <option value="">Select Sports</option>
                            <option value="Cricket">Cricket</option>
                            <option value="Badminton">Badminton</option>
                            <option value="Football">Football</option>
                        </select>
                        @error('event_name')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    <input type="hidden" name="event_start" id="event_start" value="{{$start_date}}">
                    <input type="hidden" name="athlete_id" id="athlete_id" value="{{request()->id}}">
                    <input type="hidden" name="type" id="type" value={{$type}}>
                    </div>
                </div>
                <div class="row g-2">
                    <div class="col mb-3">
                    <input type="text" id="event_location" name="event_location" class="form-control @error('event_location') is-invalid @enderror" placeholder="Location"/>
                    @error('event_location')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    </div>
                </div>
                <div class="row g-2">
                    <div class="col mb-3">
                    <input type="text" id="time" name="time" class="form-control" placeholder="Select Time"/>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="button" value="Done" onclick="addSchedule()" class="btn btn-primary addtodoitemBtn" id="addtodoitemBtn"/>
            </div>
        </form>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script>
var calendar = $('#full_calendar_events').fullCalendar({});
function addSchedule(){
    var fd = new FormData(document.getElementById('addScheduleForm'));
    $.ajax({
        url: "/addSchedule",
        data: fd,
        type: "POST",
        contentType: false,
        processData: false,   
        cache: false, 
        success: function (data) {
            displayMessage("Event created.");
            location.reload();
            $('#calendarModal').modal('hide');
            // calendar.fullCalendar('renderEvent', {
            //     id: data.id,
            //     title: event_name,
            //     start: event_start,
            //     end: event_end,
            //     allDay: allDay
            // }, true);
            // calendar.fullCalendar('unselect');
        }
    });
}
</script>