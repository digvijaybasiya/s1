<!DOCTYPE html>

<!-- =========================================================
* Sneat - Bootstrap 5 HTML Admin Template - Pro | v1.0.0
==============================================================

* Product Page: https://themeselection.com/products/sneat-bootstrap-html-admin-template/
* Created by: ThemeSelection
* License: You must have a valid license purchased in order to legally use the theme for your project.
* Copyright ThemeSelection (https://themeselection.com)

=========================================================
 -->
<!-- beautify ignore:start -->
<html
  lang="en"
  class="light-style customizer-hide"
  dir="ltr"
  data-theme="theme-default"
  data-assets-path="../assets/"
  data-template="vertical-menu-template-free"
>
  <head>
    <meta charset="utf-8" />
    <meta
      name="viewport"
      content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0"
    />

    <title>Register Basic - Pages | Sneat - Bootstrap 5 HTML Admin Template - Pro</title>

    <meta name="description" content="" />

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Icons. Uncomment required icon fonts -->
    <link rel="stylesheet" href="../assets/vendor/fonts/boxicons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../assets/vendor/css/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../assets/vendor/css/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../assets/css/demo.css" />
    <link rel="stylesheet" href="../assets/css/custom_css.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />

    <!-- Page CSS -->
    <!-- Page -->
    <link rel="stylesheet" href="../assets/vendor/css/pages/page-auth.css" />
    <!-- Helpers -->
    <script src="../assets/vendor/js/helpers.js"></script>

    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../assets/js/config.js"></script>
  </head>

  <body>
    <!-- Content -->

    <div class="container-xxl">
      <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner" style="max-width: 558px;">
            <div class="demo-inline-spacing custom_type_btn">
              {{-- @if(session('invite_coach_id') == '')<button type="button" id="btn_user_type" class="btn rounded-pill btn-primary cb" value="2">Coach</button>@endif --}}
                {{-- @if(session('invite_coach_id') != '')<button type="button" id="btn_user_type" class="btn rounded-pill btn-primary cb" value="1">Athlete</button>@endif --}}
                {{-- @if(session('invite_coach_id') == '')<button type="button" id="btn_user_type" class="btn rounded-pill btn-primary cb" value="3">Parent</button>@endif --}}
                <span class="invalid-feedback" role="alert" id="error_user_type"></span>
            </div>
          <!-- Register Card -->
          <div class="card">
            <div class="card-body">
              <h4 class="mb-2">
                @if(session('invite_coach_id')== '')
                  <b id="defaultregisteras">Register as a Coach </b>
                @else
                  @if(session('selected_athlete_id')== '')
                    <b>Register as a Athlete
                  @else
                    <b>Register as a Parent
                  @endif
                @endif
                {{-- <b id="selectregisteras" style="display: none;">Register as a <span id="registeras"></span></b> --}}
              </h4>

              <form id="formAuthentication" class="mb-3 custom_form-padding" method="POST">
                @csrf
                <div class="mb-3">
                  <label for="username" class="form-label">First name</label>
                  <input
                    type="text"
                    class="form-control @error('name') is-invalid @enderror"
                    id="name"
                    name="name"
                    placeholder="Enter your username"
                    autofocus required autocomplete="name"
                    value="{{ old('name') }}"
                  />
                  <span class="invalid-feedback" role="alert" id="error_name"></span>
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label">Email</label>
                  <input type="email" class="form-control @error('email') is-invalid @enderror" id="email" name="email" placeholder="Enter your email" value="{{ old('email') }}" required autocomplete="email"/>
                  <span class="invalid-feedback" role="alert" id="error_email"></span>
                </div>
                <div class="mb-3">
                  <label for="phone_number" class="form-label">Phone number</label>
                  <input type="phone_number" class="form-control @error('phone_number') is-invalid @enderror" id="phone_number" name="phone_number" placeholder="Enter your phone number" value="{{ old('phone_number') }}" required autocomplete="phone_number"/>
                        <span class="invalid-feedback" role="alert" id="error_phone_number"></span>
                </div>
                <div class="mb-3 form-password-toggle">
                  <label class="form-label" for="password">Password</label>
                  <div class="input-group input-group-merge">
                    <input
                      type="password"
                      id="password"
                      class="form-control @error('password') is-invalid @enderror"
                      name="password"
                      placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
                      aria-describedby="password"
                      required autocomplete="password"
                    />
                    <span class="invalid-feedback" role="alert" id="error_password"></span>
                    {{-- <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span> --}}
                  </div>
                </div>
                <input type="hidden" class="form-control" id="user_type" name="user_type" required autocomplete="user_type" value="{{session('invite_coach_id') != '' ? session('selected_athlete_id') != '' ? 3 : 1 : ''}}"/>
                <input type="hidden" class="form-control" id="selected_athlete_id" name="selected_athlete_id" required autocomplete="user_type" value="{{session('selected_athlete_id')}}"/>

                <div class="mb-3">
                  {{-- <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="terms-conditions" name="terms" />
                    <label class="form-check-label" for="terms-conditions">
                      I agree to
                      <a href="javascript:void(0);">privacy policy & terms</a>
                    </label>
                  </div>
                </div> --}}
                  {{-- <button class="btn btn-primary d-grid w-100 custom_btn_primary" type="submit">Register</button> --}}
                  <input type="button" onclick="registerfn()" class="btn btn-primary d-grid w-100 custom_btn_primary" type="submit" value="Register">
                </div>
                <div class="mb-3">
                  <label>Already have an account? <a href="{{ route('login' )}}">Sign In</a></label>
                </div>
                <span class="invalid-feedback" id="pwdrule" role="warning" style="display: none">
                  <b>Password Rule</b>
                  <ul>
                    <li>Password must include Capital and small letters and numbers</li>
                    <li>Password must be atleast 8 characters</li>
                    <li>Password must include special character like ($, @, %, !, #)</li>
                  </ul>
                </span>
              </form> 

              {{-- <p class="text-center">
                <span>Already have an account?</span>
                <a href="auth-login-basic.html">
                  <span>Sign in instead</span>
                </a>
              </p> --}}
            </div>
          </div>
          <!-- Register Card -->
        </div>
      </div>
    </div>

    <!-- / Content -->

    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->
    <script src="../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../assets/vendor/libs/popper/popper.js"></script>
    <script src="../assets/vendor/js/bootstrap.js"></script>
    <script src="../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>

    <script src="../assets/vendor/js/menu.js"></script>
    <!-- endbuild -->

    <!-- Vendors JS -->

    <!-- Main JS -->
    <script src="../assets/js/main.js"></script>

    <!-- Page JS -->

    <!-- Place this tag in your head or just before your close body tag. -->
    <script async defer src="https://buttons.github.io/buttons.js"></script>
  </body>
</html>
<script>
  clicked = true;
    $(".cb").click(function() {
    var btn_val = $(this).val();
    $('#user_type').val(btn_val);
    // $('#registeras').text(btn_val == 2 ? 'Coach' : 'Parent')
    // $('#selectregisteras').css('display','block');
    // $('#defaultregisteras').css('display','none');
    $("button").removeClass("active");
    clicked ? $(this).addClass("active") : $(this).removeClass("active");
});
  function registerfn(){
            $('#error_phone_number').css('display','none');
            $('#error_name').css('display','none');
            $('#error_email').css('display','none');
            $('#error_password').css('display','none');
            $('#error_user_type').css('display','none');
    var fd = new FormData(document.getElementById('formAuthentication'));
    $.ajax({    //create an ajax request to login
        type: 'POST',
        url: '/register', 
        data: fd,
        contentType: false,
        processData: false,   
        cache: false, 
        headers: { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        success: function(response)
        {                    
            console.log(response)
            window.location.href="{{url('/register_success')}}";
        },
        error:function(error){
          let allerror = error.responseJSON.errors;
          $.each(allerror, function(index, value) {
            index == 'phone_number' ? ($('#error_phone_number').css('display','block'),$('#error_phone_number').text(value)) : '';
            index == 'name' ? ($('#error_name').css('display','block'),$('#error_name').text(value)) : '';
            index == 'email' ? ($('#error_email').css('display','block'),$('#error_email').text(value)) : '';
            index == 'password' ? ($('#error_password').css('display','block'),$('#error_password').text(value)) : '';
            index == 'user_type' ? ($('#error_user_type').css('display','block'),$('#error_user_type').text(value)) : '';
            index == 'password' ? $('#pwdrule').css('display','block') : '';
          })
        }
    })
  }
</script>
