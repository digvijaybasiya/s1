
@if($response['success'] == 0)
{{$response['message']}}
@else
{{$response['message']}}
@endif
<p>Click here to do <a href="{{ route('login') }}">login</a></p>